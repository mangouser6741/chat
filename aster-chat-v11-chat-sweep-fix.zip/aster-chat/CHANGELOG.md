# Changelog

## 11.0.0

- Added a favicon and installable app icon set based on the Aster star mark used in the interface.
- Added a web app manifest, Apple touch icon, mask icon, social preview image, and publishing metadata.
- Added dynamic browser-tab titles for active conversations.
- Added a keyboard skip link, no-JavaScript fallback, forced-colors support, and touch/overscroll refinements.
- Added online/offline feedback and automatic model-status refresh after reconnection.
- Added `/healthz`, stricter response headers, sensible static caching, correct 404 handling for missing assets, and graceful shutdown behavior.
- Added a security guide and a release checklist.
- Removed `.env` from the distributable archive while retaining `.env.example`.

## 10.0.0

- Rebuilt conversation-title generation with strict validation and deterministic fallback titles, preventing leaked title prompts and permanent “New chat” entries.
- Routed active-chat highlights, action buttons, generation pulses, stage sweeps, tool sweeps, focus rings, and task states through the selected accent palette.
- Changed fresh and migrated defaults to Slate accent and Compact spacing.
- Bumped browser cache and storage versions while preserving existing conversations.

## 9.0.0

- Corrected the welcome surface and composer to use exact main-pane centering.
- Rebuilt the assistant work-plan header so its count and disclosure control align perfectly.
- Removed provider, local-host, and environment-configuration labels from the client interface.
- Added model-generated conversation titles after the first completed response instead of copying the first prompt.
- Kept provider credentials server-side and made public tunnel attribution optional.

## 8.0.0 — Exact centering and OpenRouter model routing

- Reworked the empty-state heading grid so the headline text and composer are centered to the exact chat-pane midpoint, independent of the decorative mark and sidebar state.
- Added a compact composer model selector with animated popover positioning and persisted browser selection.
- Added Gemma 4 E4B through LM Studio plus Ling 3.0 Flash and Nemotron 3 Ultra through OpenRouter.
- Added model context, throughput, uptime, provider, setup status, and availability details without exposing the API key.
- Added dependency-free project-root `.env` loading for `OPENROUTER_API_KEY`, `OPENROUTER_HTTP_REFERER`, and `OPENROUTER_APP_NAME`.
- Added server-side model validation, provider routing, OpenRouter streaming/error handling, and private authorization headers.
- Added OpenRouter streamed `reasoning_details` parsing and preservation across tool-call rounds.
- Added `/api/models` for sanitized client model metadata and readiness state.
- Added browser-storage migration from the 7.x chat key.

## 7.0.0 — Compact composer, animated plans, and local settings

- Removed the composer keyboard-hint label and orbiting three-dot generation indicator.
- Rebuilt the composer as a compact input with an anchored send/stop control and a 56px empty-state height.
- Replaced the work-plan disclosure glyph with a vendored Lucide Chevron Down icon.
- Added smooth plan expand/collapse motion and staggered task reveal animation without rerendering the entire plan.
- Added a browser-local settings drawer with dark, light, and system themes; four accents; text size; spacing density; and motion controls.
- Added assistant personality, response detail, web-tool permission, thought-process visibility, Enter-to-send behavior, and custom-instruction preferences.
- Added validated server-side handling for personality/detail/custom-instruction preferences and request-level web-tool disabling while preserving code-level tool limits.
- Added light-theme coverage for the shell, composer, messages, reasoning, tool results, code blocks, work plans, menus, toasts, and settings.
- Added browser-storage migration from the 6.x chat key while keeping preferences in a separate browser-local settings key.

## 6.0.0 — Ordered thought traces, agent plans, and code toolbars

- Changed **New chat** to open a draft home state; no conversation is added to history until the first prompt is sent.
- Added ordered thought events so reasoning and tool calls render exactly where they occurred, including post-tool reasoning.
- Replaced tool cards with bold inline tool lines and animated expandable result disclosures.
- Added full tool-result streaming from the local server to the thought trace.
- Added explicit generation phases so the Thinking label, shimmer, and brain pulse stop as soon as answer writing begins.
- Replaced the particle/scale brain animation with a color-only pulse and made the shimmer loop on an exact repeating interval.
- Replaced the brain, search, todo, and related tool glyphs with vendored Lucide icon paths and included the ISC notice.
- Made pinned checklists assistant-owned, read-only execution plans rather than user-editable todo lists.
- Added copy actions to user prompts.
- Rebuilt fenced code blocks with visible language labels and dedicated copy-code controls.
- Added browser-storage migration from the 5.x key.

## 5.0.0 — Background streams, unified thinking, and pinned tasks

- Replaced the single global generation controller with per-conversation jobs, so switching chats no longer cancels an active response.
- Added live sidebar indicators for conversations generating in the background; the composer only enters stop mode for the active chat.
- Batched token paints with `requestAnimationFrame`, throttled Markdown rendering, guarded auto-scroll, and limited transition ghosts to reduce long-chat lag.
- Rebuilt thinking as one animated disclosure instead of separate reasoning and loading elements, removing the duplicate indicator.
- Added a refined pulsing neural-brain mark and gray shimmer that stay active throughout reasoning, tool use, and answer streaming.
- Moved tool calls inside the thought process and changed them to persistent DOM rows, preventing completed tools from replaying their entrance on every token.
- Added distinct running-tool pulse and sweep effects, with stronger labels and quiet completed states.
- Added animated thought-process open/close transitions while preserving the user's closed state during streaming and chat changes.
- Added the `set_todos` model tool and per-chat pinned checklists with progress, collapse, local completion toggles, persistence, and responsive layouts.
- Added browser-storage migration from all 1.x–4.x keys.

## 4.0.0 — Message motion and inline thinking

- Removed the full-canvas sweep when sending or retrying a message; the spatial sweep now runs only for actual chat changes.
- Added bottom-rising user and assistant message entrances with blur, clipping, and a small physical settle.
- Replaced the geometric reasoning sigil and loading dots with a breathing brain icon.
- Restyled reasoning as quiet gray inline disclosure rather than a bordered card.
- Added a gray shimmer sweep to the live “Thinking” label.
- Reasoning is closed by default and remembers the user’s open or closed choice throughout live token updates, so closing it never causes it to reopen.
- Added browser-storage migration from the 3.x, 2.x, and 1.x keys.


## 3.0.0 — Chromium and Edge compatibility

- Replaced the browser-native View Transition API path with a browser-neutral outgoing-stage clone and CSS animation.
- Added alternating spatial chat-swap motion without relying on Chromium-only lifecycle behavior.
- Added `no-store` response headers and versioned asset URLs to prevent Edge, Chrome, Brave, and Cloudflare from retaining stale scripts.
- Added guarded local storage access so restricted storage does not stop the interface from loading.
- Added `-webkit-backdrop-filter` declarations while preserving opaque visual fallbacks.
- Replaced `String.prototype.replaceAll` in the browser bundle with broadly supported regular-expression replacements.
- Added scrolling and stream-decoder fallbacks.
- Kept conversation migration from the 2.x and 1.x browser storage keys.

Validation covered desktop startup, chat switching, transition cleanup, sidebar collapse, mobile drawer behavior, and a streamed reasoning response in Chromium 144 with no runtime exceptions.
