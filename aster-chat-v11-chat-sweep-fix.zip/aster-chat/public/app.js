const STORAGE_KEY = "aster.chat.v11";
const PREVIOUS_STORAGE_KEYS = ["aster.chat.v10", "aster.chat.v9", "aster.chat.v8", "aster.chat.v7", "aster.chat.v6", "aster.chat.v5", "aster.chat.v4", "aster.chat.v3", "aster.chat.v2", "aster.chat.v1"];
const SETTINGS_KEY = "aster.settings.v2";
const PREVIOUS_SETTINGS_KEY = "aster.settings.v1";

const FALLBACK_MODELS = Object.freeze([
  Object.freeze({ id: "gemma-4-e4b", label: "Gemma 4 E4B", shortLabel: "Gemma 4 E4B", context: "8,192 context", speed: "25 tok/s", uptime: "50% uptime", description: "Balanced everyday model.", available: false, status: "Checking availability…" }),
  Object.freeze({ id: "ling-3.0-flash", label: "Ling 3.0 Flash", shortLabel: "Ling 3.0 Flash", context: "262K context", speed: "85 tok/s", uptime: "99.95% uptime", description: "Fast responses for everyday work.", available: false, status: "Checking availability…" }),
  Object.freeze({ id: "nemotron-3-ultra", label: "Nemotron 3 Ultra", shortLabel: "Nemotron 3 Ultra", context: "1M context", speed: "31 tok/s", uptime: "96.15% uptime", description: "Long-context reasoning and agentic work.", available: false, status: "Checking availability…" })
]);
const MODEL_IDS = new Set(FALLBACK_MODELS.map((model) => model.id));

const DEFAULT_PREFERENCES = Object.freeze({
  theme: "dark",
  accent: "slate",
  textSize: "default",
  density: "compact",
  motion: "system",
  personality: "balanced",
  detail: "balanced",
  webAccess: true,
  showThinking: true,
  enterToSend: true,
  customInstructions: "",
  model: "gemma-4-e4b"
});

const PREFERENCE_OPTIONS = Object.freeze({
  theme: new Set(["system", "dark", "light"]),
  accent: new Set(["ember", "sage", "violet", "slate"]),
  textSize: new Set(["small", "default", "large"]),
  density: new Set(["compact", "comfortable"]),
  motion: new Set(["system", "full", "reduced"]),
  personality: new Set(["balanced", "direct", "warm", "analytical", "creative"]),
  detail: new Set(["brief", "balanced", "detailed"]),
  model: MODEL_IDS
});

const dom = {
  appShell: document.querySelector("#appShell"),
  main: document.querySelector("#main"),
  sidebar: document.querySelector("#sidebar"),
  scrim: document.querySelector("#scrim"),
  brandButton: document.querySelector("#brandButton"),
  collapseButton: document.querySelector("#collapseButton"),
  expandButton: document.querySelector("#expandButton"),
  newChatButton: document.querySelector("#newChatButton"),
  mobileNewButton: document.querySelector("#mobileNewButton"),
  menuButton: document.querySelector("#menuButton"),
  searchButton: document.querySelector("#searchButton"),
  settingsButton: document.querySelector("#settingsButton"),
  searchWrap: document.querySelector("#searchWrap"),
  historySearch: document.querySelector("#historySearch"),
  historyList: document.querySelector("#historyList"),
  clearAllButton: document.querySelector("#clearAllButton"),
  welcome: document.querySelector("#welcome"),
  welcomeComposerSlot: document.querySelector("#welcomeComposerSlot"),
  welcomeNote: document.querySelector("#welcomeNote"),
  conversation: document.querySelector("#conversation"),
  conversationHeader: document.querySelector(".conversation-header"),
  conversationTitle: document.querySelector("#conversationTitle"),
  mobileTitle: document.querySelector("#mobileTitle"),
  messages: document.querySelector("#messages"),
  conversationComposerSlot: document.querySelector("#conversationComposerSlot"),
  clearChatButton: document.querySelector("#clearChatButton"),
  todoDock: document.querySelector("#todoDock"),
  composer: document.querySelector("#composer"),
  promptInput: document.querySelector("#promptInput"),
  sendButton: document.querySelector("#sendButton"),
  modelTrigger: document.querySelector("#modelTrigger"),
  modelTriggerLabel: document.querySelector("#modelTriggerLabel"),
  modelMenu: document.querySelector("#modelMenu"),
  modelOptions: document.querySelector("#modelOptions"),
  chatMenu: document.querySelector("#chatMenu"),
  stageFlare: document.querySelector("#stageFlare"),
  settingsLayer: document.querySelector("#settingsLayer"),
  settingsPanel: document.querySelector("#settingsPanel"),
  settingsBackdrop: document.querySelector("#settingsBackdrop"),
  settingsCloseButton: document.querySelector("#settingsCloseButton"),
  resetSettingsButton: document.querySelector("#resetSettingsButton"),
  settingsSavedStatus: document.querySelector("#settingsSavedStatus"),
  themeColorMeta: document.querySelector('meta[name="theme-color"]'),
  toast: document.querySelector("#toast")
};

const state = {
  conversations: [],
  activeId: null,
  jobs: new Map(),
  query: "",
  toastTimer: null,
  sidebarCollapsed: false,
  menuChatId: null,
  transitionTimer: null,
  transitionToken: 0,
  transitionDirection: 1,
  messageEntryIds: new Set(),
  reasoningOpenIds: new Set(),
  toolOpenIds: new Set(),
  todoArrivalChatIds: new Set(),
  persistTimer: null,
  historyHasRendered: false,
  preferences: { ...DEFAULT_PREFERENCES },
  settingsOpen: false,
  settingsSaveTimer: null,
  systemThemeListener: null,
  models: FALLBACK_MODELS.map((model) => ({ ...model })),
  modelMenuOpen: false,
  modelMenuTimer: null,
  titleJobs: new Set()
};

function uid() {
  if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}

function safeParse(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function normalizeTool(tool) {
  if (!tool || typeof tool !== "object") return null;
  return {
    id: typeof tool.id === "string" ? tool.id : uid(),
    name: typeof tool.name === "string" ? tool.name : "tool",
    label: typeof tool.label === "string" ? tool.label : "Using a tool",
    detail: typeof tool.detail === "string" ? tool.detail : "",
    result: typeof tool.result === "string" ? tool.result : "",
    status: tool.status === "done" ? "done" : "running"
  };
}

function normalizeThought(thought) {
  if (!thought || typeof thought !== "object") return null;
  if (thought.type === "reasoning" && typeof thought.text === "string") {
    return { id: typeof thought.id === "string" ? thought.id : uid(), type: "reasoning", text: thought.text };
  }
  if (thought.type === "tool") {
    const tool = normalizeTool(thought);
    return tool ? { ...tool, type: "tool" } : null;
  }
  return null;
}

function normalizeTodo(todo) {
  if (!todo || typeof todo !== "object" || !Array.isArray(todo.items)) return null;
  const items = todo.items
    .filter((item) => item && typeof item.text === "string" && item.text.trim())
    .slice(0, 16)
    .map((item) => ({
      id: typeof item.id === "string" ? item.id : uid(),
      text: item.text.trim().slice(0, 300),
      status: ["pending", "in_progress", "done"].includes(item.status) ? item.status : "pending"
    }));
  if (!items.length) return null;
  return {
    id: typeof todo.id === "string" ? todo.id : uid(),
    title: typeof todo.title === "string" && todo.title.trim() ? todo.title.trim().slice(0, 80) : "Tasks",
    items,
    collapsed: Boolean(todo.collapsed),
    updatedAt: Number(todo.updatedAt) || Date.now()
  };
}

function normalizeMessage(message) {
  if (!message || !["user", "assistant"].includes(message.role) || typeof message.content !== "string") return null;
  const legacyReasoning = typeof message.reasoning === "string" ? message.reasoning : "";
  const legacyTools = Array.isArray(message.tools) ? message.tools.map(normalizeTool).filter(Boolean) : [];
  let thoughts = Array.isArray(message.thoughts) ? message.thoughts.map(normalizeThought).filter(Boolean) : [];
  if (!thoughts.length && message.role === "assistant") {
    if (legacyReasoning) thoughts.push({ id: uid(), type: "reasoning", text: legacyReasoning });
    thoughts.push(...legacyTools.map((tool) => ({ ...tool, type: "tool" })));
  }
  return {
    id: typeof message.id === "string" ? message.id : uid(),
    role: message.role,
    content: message.content,
    reasoning: legacyReasoning,
    tools: legacyTools,
    thoughts,
    createdAt: Number(message.createdAt) || Date.now()
  };
}

function storageGet(key) {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function storageSet(key, value) {
  try {
    window.localStorage.setItem(key, value);
    return true;
  } catch {
    return false;
  }
}

function normalizePreferences(value) {
  const source = value && typeof value === "object" ? value : {};
  const next = { ...DEFAULT_PREFERENCES };
  for (const [key, options] of Object.entries(PREFERENCE_OPTIONS)) {
    if (options.has(source[key])) next[key] = source[key];
  }
  next.webAccess = source.webAccess !== false;
  next.showThinking = source.showThinking !== false;
  next.enterToSend = source.enterToSend !== false;
  next.customInstructions = typeof source.customInstructions === "string"
    ? source.customInstructions.trim().slice(0, 1200)
    : "";
  return next;
}

function loadPreferences() {
  const current = safeParse(storageGet(SETTINGS_KEY), null);
  if (current) {
    state.preferences = normalizePreferences(current);
    return;
  }

  // Preserve established behavior settings while applying the new visual defaults once.
  const previous = safeParse(storageGet(PREVIOUS_SETTINGS_KEY), null);
  state.preferences = normalizePreferences(previous);
  state.preferences.accent = DEFAULT_PREFERENCES.accent;
  state.preferences.density = DEFAULT_PREFERENCES.density;
  storageSet(SETTINGS_KEY, JSON.stringify(state.preferences));
}

function savePreferences({ announce = false } = {}) {
  clearTimeout(state.settingsSaveTimer);
  state.settingsSaveTimer = null;
  storageSet(SETTINGS_KEY, JSON.stringify(state.preferences));
  if (announce && dom.settingsSavedStatus) {
    dom.settingsSavedStatus.textContent = "Saved";
    setTimeout(() => {
      if (dom.settingsSavedStatus) dom.settingsSavedStatus.textContent = "Changes save automatically";
    }, 1200);
  }
}

function schedulePreferenceSave() {
  clearTimeout(state.settingsSaveTimer);
  state.settingsSaveTimer = setTimeout(() => savePreferences({ announce: true }), 180);
}

function systemPrefersLight() {
  try {
    return window.matchMedia("(prefers-color-scheme: light)").matches;
  } catch {
    return false;
  }
}

function resolvedTheme() {
  return state.preferences.theme === "system"
    ? (systemPrefersLight() ? "light" : "dark")
    : state.preferences.theme;
}

function applyPreferences({ rerenderMessages = false } = {}) {
  const root = document.documentElement;
  const theme = resolvedTheme();
  root.dataset.theme = theme;
  root.dataset.themePreference = state.preferences.theme;
  root.dataset.accent = state.preferences.accent;
  root.dataset.textSize = state.preferences.textSize;
  root.dataset.density = state.preferences.density;
  root.dataset.motion = state.preferences.motion;
  root.style.colorScheme = theme;
  dom.themeColorMeta?.setAttribute("content", theme === "light" ? "#f4f2ed" : "#1f1f1d");
  renderModelControls();
  if (rerenderMessages) {
    const chat = activeChat();
    if (chat?.messages.length) renderMessages(chat);
  }
}

function selectedModel() {
  return state.models.find((model) => model.id === state.preferences.model)
    || state.models[0]
    || FALLBACK_MODELS[0];
}

function modelStatusNote(model = selectedModel()) {
  if (!model) return "Unavailable";
  return model.available ? "Available" : "Currently unavailable";
}

function renderModelControls() {
  const model = selectedModel();
  if (!model) return;
  dom.modelTriggerLabel.textContent = model.shortLabel || model.label;
  dom.modelTrigger.classList.toggle("unavailable", !model.available);
  dom.modelTrigger.setAttribute("aria-label", `Choose model. Current: ${model.label}`);
  dom.modelTrigger.setAttribute("title", `${model.label} · ${model.context} · ${model.speed} · ${model.uptime}`);
  renderModelMenu();
}

function renderModelMenu() {
  if (!dom.modelOptions) return;
  const selectedId = state.preferences.model;
  dom.modelOptions.innerHTML = state.models.map((model) => `
    <button class="model-option ${model.id === selectedId ? "selected" : ""}" type="button" role="option" aria-selected="${model.id === selectedId}" data-model-id="${escapeAttribute(model.id)}">
      <span class="model-option-check" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></svg></span>
      <span class="model-option-copy"><span class="model-option-title"><strong>${escapeHtml(model.label)}</strong></span><span>${escapeHtml(model.description)}</span></span>
      <span class="model-metrics"><span>${escapeHtml(model.context)}</span><span>${escapeHtml(model.speed)}</span><span>${escapeHtml(model.uptime)}</span></span>
      <span class="model-availability ${model.available ? "ready" : "not-ready"}">${modelStatusNote(model)}</span>
    </button>`).join("");
}

function preferencePayload() {
  return {
    personality: state.preferences.personality,
    detail: state.preferences.detail,
    webAccess: state.preferences.webAccess,
    customInstructions: state.preferences.customInstructions
  };
}

function syncSettingsControls() {
  if (!dom.settingsPanel) return;
  dom.settingsPanel.querySelectorAll(".segmented[data-setting]").forEach((group) => {
    const key = group.dataset.setting;
    group.querySelectorAll("button[data-value]").forEach((button) => {
      const selected = button.dataset.value === state.preferences[key];
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
  });
  dom.settingsPanel.querySelectorAll("[data-setting-input]").forEach((input) => {
    const key = input.dataset.settingInput;
    if (!(key in state.preferences)) return;
    if (input.type === "checkbox") input.checked = Boolean(state.preferences[key]);
    else input.value = state.preferences[key];
  });
}

function setPreference(key, value) {
  if (!(key in DEFAULT_PREFERENCES)) return;
  if (PREFERENCE_OPTIONS[key] && !PREFERENCE_OPTIONS[key].has(value)) return;
  if (["webAccess", "showThinking", "enterToSend"].includes(key)) value = Boolean(value);
  if (key === "customInstructions") value = String(value || "").slice(0, 1200);
  state.preferences[key] = value;
  applyPreferences({ rerenderMessages: key === "showThinking" });
  if (key !== "customInstructions") syncSettingsControls();
  schedulePreferenceSave();
}

function loadState() {
  let saved = safeParse(storageGet(STORAGE_KEY), null);
  for (const key of PREVIOUS_STORAGE_KEYS) {
    if (saved) break;
    saved = safeParse(storageGet(key), null);
  }
  if (!saved || !Array.isArray(saved.conversations)) return;

  state.conversations = saved.conversations
    .filter((chat) => chat && typeof chat.id === "string" && Array.isArray(chat.messages))
    .map((chat) => ({
      id: chat.id,
      title: typeof chat.title === "string" ? chat.title : "New chat",
      createdAt: Number(chat.createdAt) || Date.now(),
      updatedAt: Number(chat.updatedAt) || Date.now(),
      messages: chat.messages.map(normalizeMessage).filter(Boolean),
      todo: normalizeTodo(chat.todo)
    }));

  for (const chat of state.conversations) {
    const firstUser = chat.messages.find((message) => message.role === "user" && message.content.trim());
    if (!firstUser) continue;
    if (chat.title === "New chat" || /\b(?:the user wants?|the user asks?|concise title|conversation title|chat title|return only|assistant response|system prompt|this conversation)\b/i.test(chat.title)) {
      chat.title = fallbackChatTitle(firstUser.content);
    }
  }

  state.activeId = typeof saved.activeId === "string" && state.conversations.some((chat) => chat.id === saved.activeId)
    ? saved.activeId
    : null;
  state.sidebarCollapsed = Boolean(saved.sidebarCollapsed);
}

function persist() {
  clearTimeout(state.persistTimer);
  state.persistTimer = null;
  storageSet(
    STORAGE_KEY,
    JSON.stringify({
      conversations: state.conversations,
      activeId: state.activeId,
      sidebarCollapsed: state.sidebarCollapsed
    })
  );
}

function schedulePersist(delay = 450) {
  if (state.persistTimer) return;
  state.persistTimer = setTimeout(persist, delay);
}

function activeChat() {
  return state.conversations.find((chat) => chat.id === state.activeId) || null;
}

function updateDocumentTitle(chat = activeChat()) {
  const title = chat?.title?.trim();
  document.title = title && title.toLowerCase() !== "new chat" ? `${title} · Aster` : "Aster";
}

function chatById(id) {
  return state.conversations.find((chat) => chat.id === id) || null;
}

function jobForChat(chatId) {
  return state.jobs.get(chatId) || null;
}

function activeJob() {
  return jobForChat(state.activeId);
}

function isChatGenerating(chatId) {
  return state.jobs.has(chatId);
}


function prefersReducedMotion() {
  if (state.preferences.motion === "reduced") return true;
  if (state.preferences.motion === "full") return false;
  try {
    return typeof window.matchMedia === "function"
      && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch {
    return false;
  }
}

function fireStageFlare() {
  dom.stageFlare.classList.remove("fire");
  void dom.stageFlare.offsetWidth;
  dom.stageFlare.classList.add("fire");
}

function removeDuplicateIds(root) {
  root.removeAttribute("id");
  root.querySelectorAll("[id]").forEach((node) => node.removeAttribute("id"));
  root.querySelectorAll("button, input, textarea, select, a, [tabindex]").forEach((node) => {
    node.setAttribute("tabindex", "-1");
    if ("disabled" in node) node.disabled = true;
  });
}

function createStageGhost() {
  const source = !dom.welcome.hidden ? dom.welcome : (!dom.conversation.hidden ? dom.conversation : null);
  if (!source || !dom.main) return null;

  dom.main.querySelectorAll(".stage-ghost").forEach((node) => node.remove());
  const ghost = source.cloneNode(true);
  ghost.hidden = false;
  ghost.classList.add("stage-ghost");
  ghost.setAttribute("aria-hidden", "true");
  ghost.removeAttribute("aria-live");
  removeDuplicateIds(ghost);

  const ghostMessages = ghost.querySelector(".messages");
  const sourceMessages = source.querySelector(".messages");
  if (ghostMessages) {
    const messages = [...ghostMessages.querySelectorAll(".message")];
    messages.slice(0, Math.max(0, messages.length - 8)).forEach((node) => node.remove());
    if (sourceMessages) ghostMessages.scrollTop = sourceMessages.scrollTop;
  }

  const sourceTextarea = source.querySelector("textarea");
  const ghostTextarea = ghost.querySelector("textarea");
  if (sourceTextarea && ghostTextarea) ghostTextarea.value = sourceTextarea.value;

  dom.main.append(ghost);
  return ghost;
}

function clearStageTransition() {
  clearTimeout(state.transitionTimer);
  state.transitionTimer = null;
  dom.main?.querySelectorAll(".stage-ghost").forEach((node) => node.remove());
  dom.appShell.classList.remove("switch-in", "is-switching");
}

function renderWithTransition(mutator, { animate = true, focus = false } = {}) {
  closeChatMenu({ rerender: false });
  closeModelMenu({ restoreFocus: false });

  const update = () => {
    mutator();
    persist();
    render();
  };

  if (!animate || prefersReducedMotion()) {
    clearStageTransition();
    update();
    if (focus) requestAnimationFrame(() => dom.promptInput.focus());
    return;
  }

  clearTimeout(state.transitionTimer);
  const token = ++state.transitionToken;
  const ghost = createStageGhost();
  state.transitionDirection *= -1;
  dom.appShell.classList.toggle("switch-reverse", state.transitionDirection < 0);
  dom.appShell.classList.remove("switch-in", "is-switching");
  void dom.appShell.offsetWidth;

  update();
  fireStageFlare();
  dom.appShell.classList.add("switch-in", "is-switching");

  state.transitionTimer = setTimeout(() => {
    if (token !== state.transitionToken) return;
    ghost?.remove();
    state.transitionTimer = null;
    dom.appShell.classList.remove("switch-in", "is-switching");
    if (focus) dom.promptInput.focus();
  }, 560);
}

function buildChat() {
  return {
    id: uid(),
    title: "New chat",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: [],
    todo: null
  };
}

function openHome({ focus = true, animate = true } = {}) {
  renderWithTransition(() => {
    state.activeId = null;
    state.query = "";
    dom.historySearch.value = "";
  }, { animate, focus });
  closeSidebar();
}

function stopChatGeneration(chatId) {
  state.jobs.get(chatId)?.controller.abort();
}

function stopAllGenerations() {
  for (const job of state.jobs.values()) job.controller.abort();
}

function deleteChat(id) {
  stopChatGeneration(id);
  renderWithTransition(() => {
    state.conversations = state.conversations.filter((chat) => chat.id !== id);
    if (state.activeId === id) state.activeId = state.conversations[0]?.id || null;
  });
}

function duplicateChat(id) {
  const source = chatById(id);
  if (!source) return;
  const duplicate = {
    id: uid(),
    title: `${source.title} copy`,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: source.messages.map((message) => ({
      ...message,
      id: uid(),
      tools: message.tools.map((tool) => ({ ...tool, id: uid() })),
      thoughts: (message.thoughts || []).map((thought) => ({ ...thought, id: uid() }))
    })),
    todo: source.todo ? {
      ...source.todo,
      id: uid(),
      items: source.todo.items.map((item) => ({ ...item, id: uid() }))
    } : null
  };
  renderWithTransition(() => {
    state.conversations.unshift(duplicate);
    state.activeId = duplicate.id;
  }, { focus: true });
}

function renameChat(id) {
  const chat = chatById(id);
  if (!chat) return;
  const next = prompt("Rename this chat", chat.title)?.trim();
  if (!next) return;
  chat.title = next.slice(0, 80);
  chat.updatedAt = Date.now();
  persist();
  render();
}

function clearCurrentChat() {
  const chat = activeChat();
  if (!chat) return;
  stopChatGeneration(chat.id);
  renderWithTransition(() => {
    chat.messages = [];
    chat.todo = null;
    chat.title = "New chat";
    chat.updatedAt = Date.now();
  }, { focus: true });
}

function clearAllChats() {
  if (!state.conversations.length) return;
  if (!confirm("Clear every saved conversation from this browser?")) return;
  stopAllGenerations();
  renderWithTransition(() => {
    state.conversations = [];
    state.activeId = null;
  }, { focus: true });
}

function selectChat(id) {
  if (state.activeId === id) {
    closeSidebar();
    return;
  }
  renderWithTransition(() => {
    state.activeId = id;
  }, { focus: true });
  closeSidebar();
}

function sparkIcon() {
  return `<svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M12 3v5M12 16v5M3 12h5M16 12h5M5.6 5.6l3.5 3.5M14.9 14.9l3.5 3.5M18.4 5.6l-3.5 3.5M9.1 14.9l-3.5 3.5" />
  </svg>`;
}

function renderHistory() {
  const query = state.query.trim().toLowerCase();
  const chats = [...state.conversations]
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .filter((chat) => !query || chat.title.toLowerCase().includes(query));

  if (!chats.length) {
    dom.historyList.innerHTML = `<div class="empty-history">${query ? "No matching chats." : "No chats yet."}</div>`;
    return;
  }

  const animate = !state.historyHasRendered;
  dom.historyList.innerHTML = chats
    .map((chat, index) => `
      <div class="history-item ${chat.id === state.activeId ? "active" : ""} ${isChatGenerating(chat.id) ? "working" : ""}" data-chat-id="${escapeAttribute(chat.id)}"${animate ? ` style="animation-delay:${Math.min(index * 22, 180)}ms"` : ""}>
        <button class="history-open" type="button" title="${escapeAttribute(chat.title)}"><span>${escapeHtml(chat.title)}</span>${isChatGenerating(chat.id) ? '<i class="history-live" aria-label="Generating"></i>' : ""}</button>
        <button class="chat-spark" type="button" aria-label="Actions for ${escapeAttribute(chat.title)}" aria-expanded="${state.menuChatId === chat.id}">
          ${sparkIcon()}
        </button>
      </div>`)
    .join("");
  state.historyHasRendered = true;
}

// Lucide icons are vendored as SVG paths under the ISC license. See THIRD_PARTY_NOTICES.md.
const LUCIDE_PATHS = Object.freeze({
  brain: '<path d="M12 18V5"/><path d="M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4"/><path d="M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5"/><path d="M17.997 5.125a4 4 0 0 1 2.526 5.77"/><path d="M18 18a4 4 0 0 0 2-7.464"/><path d="M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517"/><path d="M6 18a4 4 0 0 1-2-7.464"/><path d="M6.003 5.125a4 4 0 0 0-2.526 5.77"/>',
  search: '<path d="m21 21-4.34-4.34"/><circle cx="11" cy="11" r="8"/>',
  todo: '<path d="M13 5h8"/><path d="M13 12h8"/><path d="M13 19h8"/><path d="m3 17 2 2 4-4"/><rect x="3" y="4" width="6" height="6" rx="1"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h6"/>',
  copy: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  chevronDown: '<path d="m6 9 6 6 6-6"/>'
});

function lucideIcon(name, className = "") {
  return `<svg${className ? ` class="${className}"` : ""} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${LUCIDE_PATHS[name] || LUCIDE_PATHS.file}</svg>`;
}

function brainIcon(className = "reasoning-brain") {
  return lucideIcon("brain", className);
}

function toolIcon(name) {
  if (name === "search_web") return lucideIcon("search");
  if (name === "open_webpage") return lucideIcon("globe");
  if (name === "set_todos") return lucideIcon("todo");
  return lucideIcon("file");
}

function messageThoughts(message) {
  if (Array.isArray(message.thoughts) && message.thoughts.length) return message.thoughts;
  const fallback = [];
  if (message.reasoning) fallback.push({ id: `${message.id}-reasoning`, type: "reasoning", text: message.reasoning });
  for (const tool of message.tools || []) fallback.push({ ...tool, type: "tool" });
  return fallback;
}

function renderToolThought(tool) {
  const open = state.toolOpenIds.has(tool.id);
  const hasResult = Boolean(tool.result || tool.detail);
  return `<section class="thought-tool ${tool.status === "done" ? "done" : "running"} ${open ? "open" : ""}" data-tool-id="${escapeAttribute(tool.id)}">
    <button class="tool-toggle" type="button" aria-expanded="${open}" ${hasResult ? "" : "disabled"}>
      <span class="tool-icon">${toolIcon(tool.name)}</span>
      <span class="tool-copy"><strong>${escapeHtml(tool.label)}</strong>${tool.detail ? `<small>${escapeHtml(tool.detail)}</small>` : ""}</span>
      <span class="tool-state">${tool.status === "done" ? "done" : "working"}</span>
      <span class="tool-chevron" aria-hidden="true"></span>
    </button>
    <div class="tool-result-wrap" aria-hidden="${!open}"><div class="tool-result-inner"><pre>${escapeHtml(tool.result || tool.detail || "No result returned.")}</pre></div></div>
  </section>`;
}

function renderThoughtTimeline(message) {
  return `<div class="thought-timeline">${messageThoughts(message).map((thought) => {
    if (thought.type === "tool") return renderToolThought(thought);
    return `<div class="thought-text" data-thought-id="${escapeAttribute(thought.id)}">${escapeHtml(thought.text)}</div>`;
  }).join("")}</div>`;
}

function shouldShowReasoning(message, phase = "idle") {
  if (!state.preferences.showThinking) return false;
  return Boolean(phase !== "idle" || messageThoughts(message).length);
}

function renderReasoning(message, phase = "idle") {
  if (!shouldShowReasoning(message, phase)) return "";
  const isOpen = state.reasoningOpenIds.has(message.id);
  const active = phase === "thinking" || phase === "tool";
  return `<section class="reasoning-block ${active ? "active-thinking" : ""} ${phase === "tool" ? "active-tool" : ""} ${isOpen ? "open" : ""}" data-reasoning-for="${escapeAttribute(message.id)}">
    <button class="reasoning-toggle" type="button" aria-expanded="${isOpen}" aria-controls="reasoning-panel-${escapeAttribute(message.id)}">
      <span class="brain-shell">${brainIcon()}</span>
      <span class="reasoning-label">${active ? "Thinking" : "Thought process"}</span>
      <span class="reasoning-chevron" aria-hidden="true"></span>
    </button>
    <div class="reasoning-panel-wrap" id="reasoning-panel-${escapeAttribute(message.id)}" aria-hidden="${!isOpen}">
      <div class="reasoning-panel-inner">${renderThoughtTimeline(message)}</div>
    </div>
  </section>`;
}

function renderAssistantBody(message, phase = "idle") {
  const streaming = phase !== "idle";
  const answer = message.content
    ? `<div class="message-content">${renderMarkdown(message.content)}${streaming ? '<span class="streaming-caret" aria-hidden="true"></span>' : ""}</div>`
    : `<div class="message-content" ${streaming ? "" : "hidden"}>${streaming ? '<span class="streaming-caret" aria-hidden="true"></span>' : ""}</div>`;
  return `${renderReasoning(message, phase)}${answer}`;
}

function assistantActions(messageId) {
  return `<div class="message-actions">
    <button class="message-action copy-message" type="button" data-message-id="${escapeAttribute(messageId)}">
      ${lucideIcon("copy")}Copy
    </button>
    <button class="message-action retry-message" type="button" data-message-id="${escapeAttribute(messageId)}">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6"/></svg>Retry
    </button>
  </div>`;
}

function userActions(messageId) {
  return `<div class="message-actions user-message-actions"><button class="message-action copy-message" type="button" data-message-id="${escapeAttribute(messageId)}">${lucideIcon("copy")}Copy</button></div>`;
}

function renderMessages(chat) {
  const job = jobForChat(chat.id);
  dom.messages.innerHTML = chat.messages
    .map((message) => {
      const entering = state.messageEntryIds.has(message.id);
      if (message.role === "user") {
        return `<article class="message user ${entering ? "message-enter-user" : ""}" data-message-id="${escapeAttribute(message.id)}"><div class="message-body">${escapeHtml(message.content)}</div>${userActions(message.id)}</article>`;
      }
      const phase = job && job.assistantId === message.id ? job.phase : "idle";
      return `<article class="message assistant ${phase !== "idle" ? "streaming" : ""} ${entering ? "message-enter-assistant" : ""}" data-message-id="${escapeAttribute(message.id)}">
        ${renderAssistantBody(message, phase)}
        ${phase !== "idle" ? "" : assistantActions(message.id)}
      </article>`;
    })
    .join("");

  state.messageEntryIds.clear();
  enhanceCodeBlocks();
}

function renderTodoDock(chat) {
  const todo = chat?.todo;
  if (!todo) {
    dom.todoDock.hidden = true;
    dom.todoDock.innerHTML = "";
    dom.conversation.classList.remove("has-todos");
    return;
  }

  const done = todo.items.filter((item) => item.status === "done").length;
  const progress = Math.round((done / todo.items.length) * 100);
  const arriving = state.todoArrivalChatIds.delete(chat.id);
  dom.todoDock.hidden = false;
  dom.conversation.classList.add("has-todos");
  dom.todoDock.className = `todo-dock ${todo.collapsed ? "collapsed" : ""} ${arriving ? "todo-arrive" : ""}`;
  dom.todoDock.innerHTML = `<div class="todo-head">
    <button class="todo-collapse" type="button" aria-expanded="${!todo.collapsed}">
      <span class="todo-pin-icon" aria-hidden="true">${lucideIcon("todo")}</span>
      <strong class="todo-title">${escapeHtml(todo.title)}</strong>
      <span class="todo-meta"><small>${done} of ${todo.items.length}</small><span class="todo-chevron" aria-hidden="true">${lucideIcon("chevronDown")}</span></span>
    </button>
  </div>
  <div class="todo-progress"><i style="width:${progress}%"></i></div>
  <div class="todo-list-wrap" aria-hidden="${todo.collapsed}"><div class="todo-list-inner">
    ${todo.items.map((item, index) => `<div class="todo-item ${item.status}" style="--task-index:${index}">
      <span class="todo-check" aria-hidden="true"><svg viewBox="0 0 16 16"><path d="m3 8 3 3 7-7"/></svg></span>
      <span>${escapeHtml(item.text)}</span>
    </div>`).join("")}
  </div></div>`;
}

function renderComposerState() {
  const generating = Boolean(activeJob());
  const empty = !dom.promptInput.value.trim();
  dom.composer.classList.toggle("generating", generating);
  dom.composer.classList.toggle("is-empty", empty);
  dom.sendButton.disabled = !generating && empty;
  dom.sendButton.setAttribute("aria-label", generating ? "Stop response" : "Send message");
}

function render() {
  renderHistory();
  const chat = activeChat();
  const hasMessages = Boolean(chat?.messages.length);

  dom.appShell.classList.toggle("sidebar-collapsed", state.sidebarCollapsed);
  dom.collapseButton.setAttribute("aria-expanded", String(!state.sidebarCollapsed));
  dom.expandButton.hidden = !state.sidebarCollapsed;
  dom.welcome.hidden = hasMessages;
  dom.conversation.hidden = !hasMessages;

  if (!hasMessages) {
    if (dom.composer.parentElement !== dom.welcomeComposerSlot) dom.welcomeComposerSlot.append(dom.composer);
    dom.mobileTitle.textContent = "Aster";
    updateDocumentTitle(null);
    dom.promptInput.placeholder = "Ask anything…";
    renderTodoDock(null);
  } else {
    if (dom.composer.parentElement !== dom.conversationComposerSlot) dom.conversationComposerSlot.append(dom.composer);
    dom.conversationTitle.textContent = chat.title;
    dom.mobileTitle.textContent = chat.title;
    updateDocumentTitle(chat);
    dom.promptInput.placeholder = "Continue the conversation…";
    renderMessages(chat);
    renderTodoDock(chat);
    requestAnimationFrame(() => scrollToBottom(false));
  }
  renderComposerState();
  renderModelControls();
}

function isNearBottom() {
  return dom.messages.scrollHeight - dom.messages.scrollTop - dom.messages.clientHeight < 120;
}

function scrollToBottom(smooth = true) {
  const top = dom.messages.scrollHeight;
  try {
    dom.messages.scrollTo({ top, behavior: smooth ? "smooth" : "auto" });
  } catch {
    dom.messages.scrollTop = top;
  }
}

function autoResize() {
  dom.promptInput.style.height = "auto";
  dom.promptInput.style.height = `${Math.min(dom.promptInput.scrollHeight, 190)}px`;
  renderComposerState();
}

function ensureReasoningShell(node, message, phase) {
  let block = node.querySelector(".reasoning-block");
  const shouldShow = shouldShowReasoning(message, phase);
  if (!shouldShow) {
    block?.remove();
    return null;
  }
  if (!block) {
    node.insertAdjacentHTML("afterbegin", renderReasoning(message, phase));
    block = node.querySelector(".reasoning-block");
  }
  const active = phase === "thinking" || phase === "tool";
  block.classList.toggle("active-thinking", active);
  block.classList.toggle("active-tool", phase === "tool");
  block.classList.toggle("open", state.reasoningOpenIds.has(message.id));
  const toggle = block.querySelector(".reasoning-toggle");
  const panel = block.querySelector(".reasoning-panel-wrap");
  toggle?.setAttribute("aria-expanded", String(state.reasoningOpenIds.has(message.id)));
  panel?.setAttribute("aria-hidden", String(!state.reasoningOpenIds.has(message.id)));
  const label = block.querySelector(".reasoning-label");
  if (label) label.textContent = active ? "Thinking" : "Thought process";
  return block;
}

function patchToolThought(node, tool) {
  node.classList.toggle("done", tool.status === "done");
  node.classList.toggle("running", tool.status !== "done");
  node.classList.toggle("open", state.toolOpenIds.has(tool.id));
  const toggle = node.querySelector(".tool-toggle");
  const hasResult = Boolean(tool.result || tool.detail);
  if (toggle) {
    toggle.disabled = !hasResult;
    toggle.setAttribute("aria-expanded", String(state.toolOpenIds.has(tool.id)));
  }
  const strong = node.querySelector(".tool-copy strong");
  if (strong) strong.textContent = tool.label;
  let small = node.querySelector(".tool-copy small");
  if (tool.detail) {
    if (!small) {
      node.querySelector(".tool-copy")?.insertAdjacentHTML("beforeend", "<small></small>");
      small = node.querySelector(".tool-copy small");
    }
    if (small) small.textContent = tool.detail;
  } else small?.remove();
  const stateNode = node.querySelector(".tool-state");
  if (stateNode) stateNode.textContent = tool.status === "done" ? "done" : "working";
  const result = node.querySelector(".tool-result-inner pre");
  if (result) result.textContent = tool.result || tool.detail || "No result returned.";
  node.querySelector(".tool-result-wrap")?.setAttribute("aria-hidden", String(!state.toolOpenIds.has(tool.id)));
}

function patchThoughtTimeline(block, message) {
  if (!block) return;
  let timeline = block.querySelector(".thought-timeline");
  if (!timeline) {
    block.querySelector(".reasoning-panel-inner")?.insertAdjacentHTML("beforeend", '<div class="thought-timeline"></div>');
    timeline = block.querySelector(".thought-timeline");
  }
  const thoughts = messageThoughts(message);
  const valid = new Set(thoughts.map((thought) => thought.id));
  timeline.querySelectorAll("[data-thought-id], [data-tool-id]").forEach((node) => {
    const id = node.dataset.thoughtId || node.dataset.toolId;
    if (!valid.has(id)) node.remove();
  });
  thoughts.forEach((thought, index) => {
    const selector = thought.type === "tool"
      ? `[data-tool-id="${cssEscape(thought.id)}"]`
      : `[data-thought-id="${cssEscape(thought.id)}"]`;
    let node = timeline.querySelector(selector);
    if (!node) {
      timeline.insertAdjacentHTML("beforeend", thought.type === "tool"
        ? renderToolThought(thought)
        : `<div class="thought-text" data-thought-id="${escapeAttribute(thought.id)}"></div>`);
      node = timeline.lastElementChild;
    }
    const expected = timeline.children[index];
    if (node !== expected) timeline.insertBefore(node, expected || null);
    if (thought.type === "tool") patchToolThought(node, thought);
    else node.textContent = thought.text;
  });
}

function patchStreamingMessage(chatId, message, { content = false, thoughts = false, phase = false } = {}) {
  if (state.activeId !== chatId) return;
  let node = dom.messages.querySelector(`[data-message-id="${cssEscape(message.id)}"]`);
  if (!node) {
    const chat = chatById(chatId);
    if (!chat) return;
    renderMessages(chat);
    node = dom.messages.querySelector(`[data-message-id="${cssEscape(message.id)}"]`);
    if (!node) return;
  }

  const job = jobForChat(chatId);
  const currentPhase = job?.phase || "idle";
  const keepPinned = isNearBottom();
  node.classList.toggle("streaming", currentPhase !== "idle");
  const reasoningBlock = ensureReasoningShell(node, message, currentPhase);
  if (thoughts || phase) patchThoughtTimeline(reasoningBlock, message);

  if (content) {
    let answer = node.querySelector(".message-content");
    if (!answer) {
      node.insertAdjacentHTML("beforeend", '<div class="message-content"></div>');
      answer = node.querySelector(".message-content");
    }
    answer.hidden = false;
    answer.innerHTML = `${renderMarkdown(message.content)}<span class="streaming-caret" aria-hidden="true"></span>`;
    enhanceCodeBlocks(answer);
  }
  if (keepPinned) scrollToBottom(false);
}

function scheduleStreamPaint(job, dirty = {}) {
  Object.assign(job.dirty, dirty);
  schedulePersist();
  if (job.paintFrame) return;
  job.paintFrame = requestAnimationFrame(() => {
    job.paintFrame = null;
    const chat = chatById(job.chatId);
    const message = chat?.messages.find((item) => item.id === job.assistantId);
    if (!message) return;

    const now = performance.now();
    const shouldPaintContent = job.dirty.content && (now - job.lastContentPaint >= 48 || !message.content);
    const pendingContent = job.dirty.content && !shouldPaintContent;
    const dirtyNow = {
      content: shouldPaintContent,
      thoughts: job.dirty.thoughts,
      phase: job.dirty.phase
    };
    if (shouldPaintContent) job.lastContentPaint = now;
    job.dirty = { content: pendingContent, thoughts: false, phase: false };
    patchStreamingMessage(job.chatId, message, dirtyNow);
    if (pendingContent) setTimeout(() => scheduleStreamPaint(job, {}), 50);
  });
}

function appendReasoningThought(message, text) {
  if (!text) return;
  let last = message.thoughts[message.thoughts.length - 1];
  if (!last || last.type !== "reasoning") {
    last = { id: uid(), type: "reasoning", text: "" };
    message.thoughts.push(last);
  }
  last.text += text;
  message.reasoning += text;
}

async function sendMessage(text) {
  const promptText = text.trim();
  if (!promptText) return;

  let chat = activeChat();
  if (!chat) {
    chat = buildChat();
    state.conversations.unshift(chat);
    state.activeId = chat.id;
  }
  if (isChatGenerating(chat.id)) return;
  if (chat.title === "New chat") chat.title = fallbackChatTitle(promptText);

  const userMessage = {
    id: uid(), role: "user", content: promptText, reasoning: "", tools: [], thoughts: [], createdAt: Date.now()
  };
  const assistantMessage = {
    id: uid(), role: "assistant", content: "", reasoning: "", tools: [], thoughts: [], createdAt: Date.now()
  };

  chat.messages.push(userMessage, assistantMessage);
  state.messageEntryIds.add(userMessage.id);
  state.messageEntryIds.add(assistantMessage.id);
  chat.updatedAt = Date.now();

  const modelId = state.preferences.model;
  const job = {
    chatId: chat.id,
    assistantId: assistantMessage.id,
    controller: new AbortController(),
    paintFrame: null,
    lastContentPaint: 0,
    phase: "thinking",
    dirty: { content: false, thoughts: false, phase: true }
  };
  state.jobs.set(chat.id, job);
  dom.promptInput.value = "";
  autoResize();
  persist();
  render();
  requestAnimationFrame(() => scrollToBottom());

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: chat.messages
          .filter((message) => message.id !== assistantMessage.id)
          .map(({ role, content }) => ({ role, content })),
        todo: chat.todo,
        model: modelId,
        preferences: preferencePayload()
      }),
      signal: job.controller.signal
    });

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.error || `Request failed with HTTP ${response.status}`);
    }
    if (!response.body) throw new Error("The response stream is unavailable.");

    await readEventStream(response.body, {
      reasoning(payload) {
        if (typeof payload.text !== "string") return;
        job.phase = "thinking";
        appendReasoningThought(assistantMessage, payload.text);
        scheduleStreamPaint(job, { thoughts: true, phase: true });
      },
      tool_start(payload) {
        const id = typeof payload.id === "string" ? payload.id : uid();
        const tool = {
          id,
          type: "tool",
          name: typeof payload.name === "string" ? payload.name : "tool",
          label: typeof payload.label === "string" ? payload.label : "Using a tool",
          detail: typeof payload.detail === "string" ? payload.detail : "",
          result: "",
          status: "running"
        };
        job.phase = "tool";
        assistantMessage.tools.push(tool);
        assistantMessage.thoughts.push(tool);
        scheduleStreamPaint(job, { thoughts: true, phase: true });
      },
      tool_result(payload) {
        const tool = assistantMessage.tools.find((item) => item.id === payload.id);
        if (tool) {
          tool.status = "done";
          if (typeof payload.detail === "string" && payload.detail) tool.detail = payload.detail;
          if (typeof payload.result === "string") tool.result = payload.result;
        }
        scheduleStreamPaint(job, { thoughts: true });
      },
      todo_update(payload) {
        const next = normalizeTodo(payload.todo);
        if (!next) return;
        next.collapsed = chat.todo?.collapsed || false;
        chat.todo = next;
        state.todoArrivalChatIds.add(chat.id);
        if (state.activeId === chat.id) renderTodoDock(chat);
        schedulePersist(80);
      },
      token(payload) {
        if (typeof payload.text !== "string") return;
        assistantMessage.content += payload.text;
        if (job.phase !== "writing") {
          job.phase = "writing";
          scheduleStreamPaint(job, { phase: true });
        }
        scheduleStreamPaint(job, { content: true });
      },
      error(payload) {
        throw new Error(payload.error || "The response stream ended with an error.");
      }
    });

    if (!assistantMessage.content.trim() && !assistantMessage.thoughts.length) {
      throw new Error("The selected model returned an empty response.");
    }
  } catch (error) {
    if (error.name === "AbortError") {
      if (!assistantMessage.content.trim() && !assistantMessage.thoughts.length) {
        chat.messages = chat.messages.filter((message) => message.id !== assistantMessage.id);
      }
    } else {
      chat.messages = chat.messages.filter((message) => message.id !== assistantMessage.id);
      showToast(error.message || "Could not reach the selected model.");
    }
  } finally {
    if (job.paintFrame) cancelAnimationFrame(job.paintFrame);
    state.jobs.delete(chat.id);
    chat.updatedAt = Date.now();
    persist();
    renderHistory();
    if (state.activeId === chat.id) {
      renderMessages(chat);
      renderTodoDock(chat);
      renderComposerState();
      requestAnimationFrame(() => scrollToBottom());
    }
    if (chat.title === "New chat" && assistantMessage.content.trim()) {
      void requestChatTitle(chat.id, modelId);
    }
  }
}

const TITLE_STOP_WORDS = new Set([
  "a", "an", "and", "are", "as", "at", "be", "been", "but", "by", "can", "could", "also", "do", "does", "either", "for", "from", "have", "help", "here", "how", "i", "in", "into", "is", "it", "just", "like", "look", "looks", "make", "me", "my", "need", "of", "on", "or", "our", "please", "really", "see", "should", "still", "that", "the", "these", "thing", "things", "this", "those", "to", "use", "want", "with", "would", "you", "your"
]);

function fallbackChatTitle(prompt) {
  const cleaned = String(prompt || "")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/https?:\/\/\S+/gi, " ")
    .replace(/\b(?:the user|user wants?|assistant|conversation|chat title|concise title)\b/gi, " ")
    .replace(/[^\p{L}\p{N}+#._'-]+/gu, " ")
    .trim();
  const tokens = (cleaned.match(/[\p{L}\p{N}][\p{L}\p{N}+#._'-]*/gu) || []).map((word) => word.replace(/^[._'-]+|[._'-]+$/g, "")).filter(Boolean);
  const meaningful = tokens.filter((word) => !TITLE_STOP_WORDS.has(word.toLowerCase()));
  const picked = (meaningful.length ? meaningful : tokens).slice(0, 6);
  if (!picked.length) return "Untitled conversation";
  return picked.map((word) => {
    if (/^[A-Z0-9+#._-]{2,}$/.test(word)) return word;
    return word.charAt(0).toUpperCase() + word.slice(1);
  }).join(" ").slice(0, 64);
}

function usableChatTitle(value) {
  const title = String(value || "").trim();
  if (!title || title.toLowerCase() === "new chat") return false;
  if (/\b(?:the user wants?|the user asks?|concise title|conversation title|chat title|return only|assistant response|system prompt|this conversation)\b/i.test(title)) return false;
  return title.split(/\s+/).length <= 9 && title.length <= 80;
}

function titleTerm(value) {
  let term = String(value || "").toLowerCase().replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
  if (term.length > 5) term = term.replace(/(?:ing|ers?|ed|es|s)$/i, "");
  return term;
}

function titleMatchesPrompt(title, prompt) {
  const titleTerms = [...new Set((String(title).match(/[\p{L}\p{N}]+/gu) || [])
    .map(titleTerm).filter((term) => term && !TITLE_STOP_WORDS.has(term)))];
  const promptTerms = new Set((String(prompt).match(/[\p{L}\p{N}]+/gu) || [])
    .map(titleTerm).filter((term) => term && !TITLE_STOP_WORDS.has(term)));
  if (!titleTerms.length || !promptTerms.size) return false;
  const overlap = titleTerms.filter((term) => promptTerms.has(term)).length;
  return overlap >= Math.min(2, titleTerms.length);
}

function commitChatTitle(chat, title, expectedTitle = "New chat") {
  if (!chat || chat.title !== expectedTitle) return;
  chat.title = title.slice(0, 80);
  chat.updatedAt = Date.now();
  persist();
  renderHistory();
  if (state.activeId === chat.id) {
    dom.conversationTitle.textContent = chat.title;
    dom.mobileTitle.textContent = chat.title;
    updateDocumentTitle(chat);
  }
}

async function requestChatTitle(chatId, modelId) {
  const chat = chatById(chatId);
  if (!chat || state.titleJobs.has(chatId)) return;
  const firstUser = chat.messages.find((message) => message.role === "user" && message.content.trim());
  const firstAssistant = chat.messages.find((message) => message.role === "assistant" && message.content.trim());
  if (!firstUser || !firstAssistant) return;

  const fallback = fallbackChatTitle(firstUser.content);
  if (chat.title !== "New chat" && chat.title !== fallback) return;
  state.titleJobs.add(chatId);
  if (chat.title === "New chat") commitChatTitle(chat, fallback);
  try {
    const response = await fetch("/api/title", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: modelId,
        user: firstUser.content.slice(0, 5000),
        assistant: firstAssistant.content.slice(0, 5000)
      })
    });
    const data = response.ok ? await response.json().catch(() => ({})) : {};
    const generated = typeof data.title === "string" ? data.title.trim() : "";
    if (usableChatTitle(generated) && titleMatchesPrompt(generated, firstUser.content)) commitChatTitle(chat, generated, fallback);
  } catch {
    // The deterministic title was already committed, so title generation never blocks the UI.
  } finally {
    state.titleJobs.delete(chatId);
  }
}

async function retryFrom(messageId) {
  const chat = activeChat();
  if (!chat || isChatGenerating(chat.id)) return;
  const assistantIndex = chat.messages.findIndex((message) => message.id === messageId && message.role === "assistant");
  if (assistantIndex < 1) return;
  const priorUser = chat.messages[assistantIndex - 1];
  if (!priorUser || priorUser.role !== "user") return;
  chat.messages = chat.messages.slice(0, assistantIndex - 1);
  persist();
  await sendMessage(priorUser.content);
}

async function readEventStream(stream, handlers) {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let currentEvent = "message";
  let dataLines = [];

  function dispatch() {
    if (!dataLines.length) {
      currentEvent = "message";
      return;
    }
    const raw = dataLines.join("\n");
    dataLines = [];
    let payload;
    try {
      payload = JSON.parse(raw);
    } catch {
      payload = { text: raw };
    }
    const handler = handlers[currentEvent];
    currentEvent = "message";
    if (handler) handler(payload);
  }

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, "\n");
    let newline;
    while ((newline = buffer.indexOf("\n")) !== -1) {
      const line = buffer.slice(0, newline);
      buffer = buffer.slice(newline + 1);
      if (line === "") dispatch();
      else if (line.startsWith("event:")) currentEvent = line.slice(6).trim();
      else if (line.startsWith("data:")) dataLines.push(line.slice(5).trimStart());
    }
  }
  buffer += decoder.decode();
  if (buffer.trim()) dataLines.push(buffer.trim());
  dispatch();
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}

function cssEscape(value) {
  return globalThis.CSS?.escape ? CSS.escape(value) : value.replace(/[^a-zA-Z0-9_-]/g, "\\$&");
}

function renderInline(text) {
  const codeTokens = [];
  let value = escapeHtml(text).replace(/`([^`]+)`/g, (_match, code) => {
    const token = `@@CODE${codeTokens.length}@@`;
    codeTokens.push(`<code>${code}</code>`);
    return token;
  });

  value = value
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noreferrer noopener">$1</a>')
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/__([^_]+)__/g, "<strong>$1</strong>")
    .replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>")
    .replace(/(^|[^_])_([^_\n]+)_/g, "$1<em>$2</em>");

  codeTokens.forEach((html, index) => {
    value = value.replace(`@@CODE${index}@@`, html);
  });
  return value;
}

function renderMarkdown(markdown) {
  const source = String(markdown).replace(/\r\n/g, "\n");
  const codeBlocks = [];
  const tokenized = source.replace(/```([^\n`]*)\n([\s\S]*?)```/g, (_match, language, code) => {
    const token = `@@BLOCK${codeBlocks.length}@@`;
    codeBlocks.push(`<pre data-language="${escapeAttribute(language.trim())}"><code>${escapeHtml(code.replace(/\n$/, ""))}</code></pre>`);
    return `\n${token}\n`;
  });

  const lines = tokenized.split("\n");
  const output = [];
  let paragraph = [];
  let listType = null;
  let listItems = [];
  let quoteLines = [];

  const flushParagraph = () => {
    if (!paragraph.length) return;
    output.push(`<p>${renderInline(paragraph.join(" "))}</p>`);
    paragraph = [];
  };
  const flushList = () => {
    if (!listType) return;
    output.push(`<${listType}>${listItems.map((item) => `<li>${renderInline(item)}</li>`).join("")}</${listType}>`);
    listType = null;
    listItems = [];
  };
  const flushQuote = () => {
    if (!quoteLines.length) return;
    output.push(`<blockquote>${quoteLines.map((line) => renderInline(line)).join("<br>")}</blockquote>`);
    quoteLines = [];
  };

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();
    const trimmed = line.trim();
    if (!trimmed) {
      flushParagraph(); flushList(); flushQuote(); continue;
    }
    const blockMatch = trimmed.match(/^@@BLOCK(\d+)@@$/);
    if (blockMatch) {
      flushParagraph(); flushList(); flushQuote();
      output.push(codeBlocks[Number(blockMatch[1])] || "");
      continue;
    }
    const heading = trimmed.match(/^(#{1,3})\s+(.+)$/);
    if (heading) {
      flushParagraph(); flushList(); flushQuote();
      const level = heading[1].length;
      output.push(`<h${level}>${renderInline(heading[2])}</h${level}>`);
      continue;
    }
    const unordered = trimmed.match(/^[-*+]\s+(.+)$/);
    const ordered = trimmed.match(/^\d+[.)]\s+(.+)$/);
    if (unordered || ordered) {
      flushParagraph(); flushQuote();
      const nextType = unordered ? "ul" : "ol";
      if (listType && listType !== nextType) flushList();
      listType = nextType;
      listItems.push((unordered || ordered)[1]);
      continue;
    }
    const quote = trimmed.match(/^>\s?(.*)$/);
    if (quote) {
      flushParagraph(); flushList();
      quoteLines.push(quote[1]);
      continue;
    }
    flushList(); flushQuote(); paragraph.push(trimmed);
  }

  flushParagraph(); flushList(); flushQuote();
  return output.join("");
}

function enhanceCodeBlocks(root = dom.messages) {
  root.querySelectorAll(".message-content pre:not([data-enhanced])").forEach((pre) => {
    pre.dataset.enhanced = "true";
    const language = (pre.dataset.language || "text").trim().toLowerCase() || "text";
    const header = document.createElement("div");
    header.className = "code-toolbar";
    const label = document.createElement("span");
    label.className = "code-language";
    label.textContent = language;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "code-copy";
    button.innerHTML = `${lucideIcon("copy")}<span>Copy code</span>`;
    button.addEventListener("click", async () => {
      await copyText(pre.querySelector("code")?.textContent || "");
      button.classList.add("copied");
      button.querySelector("span").textContent = "Copied";
      setTimeout(() => {
        button.classList.remove("copied");
        button.querySelector("span").textContent = "Copy code";
      }, 1200);
    });
    header.append(label, button);
    pre.prepend(header);
  });
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast("Copied to clipboard.");
  } catch {
    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.append(area);
    area.select();
    document.execCommand("copy");
    area.remove();
    showToast("Copied to clipboard.");
  }
}

function showToast(message) {
  clearTimeout(state.toastTimer);
  dom.toast.textContent = message;
  dom.toast.classList.add("visible");
  state.toastTimer = setTimeout(() => dom.toast.classList.remove("visible"), 3200);
}

function openSidebar() {
  dom.sidebar.classList.add("open");
  dom.scrim.hidden = false;
  requestAnimationFrame(() => dom.scrim.classList.add("visible"));
}

function closeSidebar() {
  dom.sidebar.classList.remove("open");
  dom.scrim.classList.remove("visible");
  setTimeout(() => {
    if (!dom.sidebar.classList.contains("open")) dom.scrim.hidden = true;
  }, 190);
}

function setSidebarCollapsed(collapsed) {
  state.sidebarCollapsed = collapsed;
  persist();
  render();
  requestAnimationFrame(() => dom.promptInput.focus());
}

function toggleSearch() {
  const next = dom.searchWrap.hidden;
  dom.searchWrap.hidden = !next;
  dom.searchButton.setAttribute("aria-expanded", String(next));
  if (next) requestAnimationFrame(() => dom.historySearch.focus());
  else {
    state.query = "";
    dom.historySearch.value = "";
    renderHistory();
  }
}

function positionModelMenu() {
  if (!state.modelMenuOpen || dom.modelMenu.hidden) return;
  const rect = dom.modelTrigger.getBoundingClientRect();
  const viewportGap = 10;
  const width = Math.min(440, window.innerWidth - viewportGap * 2);
  dom.modelMenu.style.width = `${width}px`;
  const menuRect = dom.modelMenu.getBoundingClientRect();
  const left = Math.max(viewportGap, Math.min(window.innerWidth - width - viewportGap, rect.right - width));
  let top = rect.top - menuRect.height - 10;
  if (top < viewportGap) top = Math.min(window.innerHeight - menuRect.height - viewportGap, rect.bottom + 10);
  dom.modelMenu.style.left = `${left}px`;
  dom.modelMenu.style.top = `${Math.max(viewportGap, top)}px`;
}

function openModelMenu() {
  if (state.modelMenuOpen) return;
  closeChatMenu();
  clearTimeout(state.modelMenuTimer);
  state.modelMenuOpen = true;
  renderModelMenu();
  dom.modelMenu.hidden = false;
  dom.modelTrigger.setAttribute("aria-expanded", "true");
  requestAnimationFrame(() => {
    positionModelMenu();
    dom.modelMenu.classList.add("visible");
    dom.modelOptions.querySelector('[aria-selected="true"]')?.focus({ preventScroll: true });
  });
}

function closeModelMenu({ restoreFocus = false } = {}) {
  if (!state.modelMenuOpen && dom.modelMenu.hidden) return;
  state.modelMenuOpen = false;
  dom.modelTrigger.setAttribute("aria-expanded", "false");
  dom.modelMenu.classList.remove("visible");
  clearTimeout(state.modelMenuTimer);
  state.modelMenuTimer = setTimeout(() => {
    if (!state.modelMenuOpen) dom.modelMenu.hidden = true;
  }, prefersReducedMotion() ? 0 : 160);
  if (restoreFocus) dom.modelTrigger.focus();
}

function chooseModel(modelId) {
  if (!MODEL_IDS.has(modelId)) return;
  state.preferences.model = modelId;
  savePreferences({ announce: false });
  renderModelControls();
  closeModelMenu({ restoreFocus: true });
  const model = selectedModel();
  showToast(model.available ? `${model.label} selected.` : "This model is currently unavailable.");
}

function openChatMenu(button, chatId) {
  state.menuChatId = chatId;
  renderHistory();
  const liveButton = dom.historyList.querySelector(`[data-chat-id="${cssEscape(chatId)}"] .chat-spark`) || button;
  const rect = liveButton.getBoundingClientRect();
  dom.chatMenu.hidden = false;
  const menuWidth = 148;
  const left = Math.max(10, Math.min(window.innerWidth - menuWidth - 10, rect.right - menuWidth));
  const top = Math.min(window.innerHeight - 126, rect.bottom + 7);
  dom.chatMenu.style.left = `${left}px`;
  dom.chatMenu.style.top = `${top}px`;
  requestAnimationFrame(() => dom.chatMenu.querySelector("button")?.focus());
}

function closeChatMenu({ rerender = true } = {}) {
  if (dom.chatMenu.hidden && !state.menuChatId) return;
  dom.chatMenu.hidden = true;
  state.menuChatId = null;
  if (rerender) renderHistory();
}


function openSettings() {
  if (state.settingsOpen) return;
  closeModelMenu({ restoreFocus: false });
  state.settingsOpen = true;
  syncSettingsControls();
  dom.settingsLayer.hidden = false;
  dom.settingsButton?.setAttribute("aria-expanded", "true");
  document.body.classList.add("settings-open");
  closeSidebar();
  requestAnimationFrame(() => {
    dom.settingsLayer.classList.add("visible");
    dom.settingsCloseButton?.focus();
  });
}

function closeSettings({ restoreFocus = true } = {}) {
  if (!state.settingsOpen) return;
  state.settingsOpen = false;
  dom.settingsLayer.classList.remove("visible");
  dom.settingsButton?.setAttribute("aria-expanded", "false");
  document.body.classList.remove("settings-open");
  setTimeout(() => {
    if (!state.settingsOpen) dom.settingsLayer.hidden = true;
  }, prefersReducedMotion() ? 0 : 280);
  if (restoreFocus) setTimeout(() => dom.settingsButton?.focus(), prefersReducedMotion() ? 0 : 140);
}

function toggleTodoDock(chat) {
  if (!chat?.todo) return;
  const collapsed = !chat.todo.collapsed;
  chat.todo.collapsed = collapsed;
  persist();
  dom.todoDock.classList.toggle("collapsed", collapsed);
  dom.todoDock.classList.remove("revealing");
  const button = dom.todoDock.querySelector(".todo-collapse");
  const wrap = dom.todoDock.querySelector(".todo-list-wrap");
  button?.setAttribute("aria-expanded", String(!collapsed));
  wrap?.setAttribute("aria-hidden", String(collapsed));
  if (!collapsed && !prefersReducedMotion()) {
    void dom.todoDock.offsetWidth;
    dom.todoDock.classList.add("revealing");
    setTimeout(() => dom.todoDock.classList.remove("revealing"), 520);
  }
}

function toggleToolResult(toolId) {
  if (state.toolOpenIds.has(toolId)) state.toolOpenIds.delete(toolId);
  else state.toolOpenIds.add(toolId);
  const node = dom.messages.querySelector(`[data-tool-id="${cssEscape(toolId)}"]`);
  const isOpen = state.toolOpenIds.has(toolId);
  node?.classList.toggle("open", isOpen);
  node?.querySelector(".tool-toggle")?.setAttribute("aria-expanded", String(isOpen));
  node?.querySelector(".tool-result-wrap")?.setAttribute("aria-hidden", String(!isOpen));
}
function toggleReasoning(messageId) {
  if (state.reasoningOpenIds.has(messageId)) state.reasoningOpenIds.delete(messageId);
  else state.reasoningOpenIds.add(messageId);
  const block = dom.messages.querySelector(`[data-message-id="${cssEscape(messageId)}"] .reasoning-block`);
  const isOpen = state.reasoningOpenIds.has(messageId);
  block?.classList.toggle("open", isOpen);
  block?.querySelector(".reasoning-toggle")?.setAttribute("aria-expanded", String(isOpen));
  block?.querySelector(".reasoning-panel-wrap")?.setAttribute("aria-hidden", String(!isOpen));
}

async function checkConnection() {
  try {
    const response = await fetch("/api/models", { cache: "no-store" });
    const data = await response.json();
    if (Array.isArray(data.models) && data.models.length) {
      state.models = data.models.filter((model) => model && MODEL_IDS.has(model.id));
      if (!state.models.some((model) => model.id === state.preferences.model)) {
        state.preferences.model = data.defaultModel && MODEL_IDS.has(data.defaultModel)
          ? data.defaultModel
          : FALLBACK_MODELS[0].id;
        savePreferences();
      }
      renderModelControls();
    }
  } catch {
    state.models = FALLBACK_MODELS.map((model) => ({ ...model, status: "Status unavailable" }));
    renderModelControls();
  }
}

dom.composer.addEventListener("submit", (event) => {
  event.preventDefault();
  const job = activeJob();
  if (job) job.controller.abort();
  else sendMessage(dom.promptInput.value);
});

dom.promptInput.addEventListener("input", autoResize);
dom.promptInput.addEventListener("keydown", (event) => {
  const sendShortcut = state.preferences.enterToSend
    ? event.key === "Enter" && !event.shiftKey
    : event.key === "Enter" && (event.metaKey || event.ctrlKey);
  if (sendShortcut && !event.isComposing) {
    event.preventDefault();
    if (!activeJob()) sendMessage(dom.promptInput.value);
  }
  if (event.key === "Escape" && activeJob()) activeJob().controller.abort();
});

dom.modelTrigger.addEventListener("click", () => state.modelMenuOpen ? closeModelMenu({ restoreFocus: true }) : openModelMenu());
dom.modelOptions.addEventListener("click", (event) => {
  const option = event.target.closest("[data-model-id]");
  if (option) chooseModel(option.dataset.modelId);
});

dom.newChatButton.addEventListener("click", () => openHome());
dom.mobileNewButton.addEventListener("click", () => openHome());
dom.brandButton.addEventListener("click", () => openHome());
dom.menuButton.addEventListener("click", openSidebar);
dom.scrim.addEventListener("click", closeSidebar);
dom.collapseButton.addEventListener("click", () => setSidebarCollapsed(true));
dom.expandButton.addEventListener("click", () => setSidebarCollapsed(false));
dom.searchButton.addEventListener("click", toggleSearch);
dom.settingsButton.addEventListener("click", () => state.settingsOpen ? closeSettings() : openSettings());
dom.settingsBackdrop.addEventListener("click", () => closeSettings());
dom.settingsCloseButton.addEventListener("click", () => closeSettings());
dom.resetSettingsButton.addEventListener("click", () => {
  state.preferences = { ...DEFAULT_PREFERENCES };
  applyPreferences({ rerenderMessages: true });
  syncSettingsControls();
  savePreferences({ announce: true });
});
dom.settingsPanel.addEventListener("click", (event) => {
  const button = event.target.closest(".segmented[data-setting] button[data-value]");
  if (!button) return;
  setPreference(button.closest(".segmented").dataset.setting, button.dataset.value);
});
dom.settingsPanel.addEventListener("change", (event) => {
  const input = event.target.closest("[data-setting-input]");
  if (!input || input.id === "customInstructions") return;
  setPreference(input.dataset.settingInput, input.type === "checkbox" ? input.checked : input.value);
});
dom.settingsPanel.addEventListener("input", (event) => {
  const input = event.target.closest("#customInstructions[data-setting-input]");
  if (input) setPreference("customInstructions", input.value);
});
dom.clearAllButton.addEventListener("click", clearAllChats);
dom.clearChatButton.addEventListener("click", clearCurrentChat);
dom.historySearch.addEventListener("input", () => {
  state.query = dom.historySearch.value;
  renderHistory();
});

dom.historyList.addEventListener("click", (event) => {
  const item = event.target.closest(".history-item");
  if (!item) return;
  const id = item.dataset.chatId;
  const spark = event.target.closest(".chat-spark");
  if (spark) {
    event.stopPropagation();
    if (state.menuChatId === id) closeChatMenu();
    else openChatMenu(spark, id);
  } else selectChat(id);
});

dom.chatMenu.addEventListener("click", (event) => {
  const action = event.target.closest("button")?.dataset.action;
  const id = state.menuChatId;
  if (!action || !id) return;
  closeChatMenu();
  if (action === "rename") renameChat(id);
  if (action === "duplicate") duplicateChat(id);
  if (action === "delete") deleteChat(id);
});

document.addEventListener("pointerdown", (event) => {
  if (!dom.chatMenu.hidden && !event.target.closest("#chatMenu") && !event.target.closest(".chat-spark")) closeChatMenu();
  if (state.modelMenuOpen && !event.target.closest("#modelMenu") && !event.target.closest("#modelTrigger")) closeModelMenu();
});

dom.messages.addEventListener("click", (event) => {
  const reasoningButton = event.target.closest(".reasoning-toggle");
  if (reasoningButton) {
    const messageId = reasoningButton.closest("[data-message-id]")?.dataset.messageId;
    if (messageId) toggleReasoning(messageId);
    return;
  }
  const toolButton = event.target.closest(".tool-toggle");
  if (toolButton && !toolButton.disabled) {
    const toolId = toolButton.closest("[data-tool-id]")?.dataset.toolId;
    if (toolId) toggleToolResult(toolId);
    return;
  }

  const copyButton = event.target.closest(".copy-message");
  const retryButton = event.target.closest(".retry-message");
  const chat = activeChat();
  if (!chat) return;
  if (copyButton) {
    const message = chat.messages.find((item) => item.id === copyButton.dataset.messageId);
    if (message) copyText(message.content);
  }
  if (retryButton) retryFrom(retryButton.dataset.messageId);
});

dom.todoDock.addEventListener("click", (event) => {
  const collapse = event.target.closest(".todo-collapse");
  const chat = activeChat();
  if (!chat?.todo || !collapse) return;
  toggleTodoDock(chat);
});

dom.messages.addEventListener("scroll", () => {
  dom.conversationHeader.classList.toggle("scrolled", dom.messages.scrollTop > 10);
});

window.addEventListener("resize", () => { closeChatMenu(); if (state.modelMenuOpen) positionModelMenu(); });
window.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault(); toggleSearch();
  }
  if ((event.metaKey || event.ctrlKey) && event.shiftKey && event.key.toLowerCase() === "o") {
    event.preventDefault(); openHome();
  }
  if ((event.metaKey || event.ctrlKey) && event.key === "\\") {
    event.preventDefault(); setSidebarCollapsed(!state.sidebarCollapsed);
  }
  if (event.key === "Escape") {
    if (state.modelMenuOpen) {
      closeModelMenu({ restoreFocus: true });
      return;
    }
    if (state.settingsOpen) {
      closeSettings();
      return;
    }
    closeChatMenu();
    if (window.innerWidth <= 900) closeSidebar();
  }
  if (state.settingsOpen && event.key === "Tab") {
    const focusable = [...dom.settingsPanel.querySelectorAll('button:not(:disabled), select:not(:disabled), textarea:not(:disabled), input:not(:disabled), [tabindex]:not([tabindex="-1"])')];
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});

window.addEventListener("beforeunload", () => {
  persist();
  savePreferences();
});

window.addEventListener("offline", () => {
  showToast("You’re offline. Existing chats remain available.");
});

window.addEventListener("online", () => {
  showToast("Connection restored.");
  checkConnection();
});

loadPreferences();
applyPreferences();
loadState();
syncSettingsControls();
try {
  const themeMedia = window.matchMedia("(prefers-color-scheme: light)");
  state.systemThemeListener = () => {
    if (state.preferences.theme === "system") applyPreferences();
  };
  themeMedia.addEventListener?.("change", state.systemThemeListener);
} catch {
  // Theme follows the current resolved value when matchMedia is unavailable.
}
render();
autoResize();
checkConnection();
requestAnimationFrame(() => dom.promptInput.focus());
