#!/usr/bin/env sh
set -eu
node server/index.js
