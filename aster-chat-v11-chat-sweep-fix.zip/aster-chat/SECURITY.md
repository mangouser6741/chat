# Security

Aster is designed to sit behind a trusted access layer. It does not include user accounts or authorization.

## Public deployments

- Protect the public hostname with Cloudflare Access or an equivalent identity-aware proxy.
- Keep `.env` and all provider credentials outside the public directory and out of version control.
- Restrict the tunnel to the Aster origin and keep the model service bound to loopback or a private interface.
- Review rate limits, model spend limits, and enabled tools before sharing the hostname.
- Keep Node.js and `cloudflared` updated.

## Reporting

Do not post credentials or exploit details in a public issue. Contact the deployment owner privately and include the affected version, reproduction steps, and impact.
