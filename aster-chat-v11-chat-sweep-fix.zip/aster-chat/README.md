# Aster

Aster is a streamlined, account-free chat interface for a private deployment behind a Cloudflare Tunnel. It runs on port `3000`, streams responses live, keeps generation running while you switch chats, displays model reasoning when available, supports guarded web tools, and lets the assistant pin its own execution plan.

The client deliberately does not reveal provider names, machine topology, or credential state. Model credentials and upstream routes stay on the Node server.

## Models

The composer includes three choices:

- **Gemma 4 E4B** — 8,192 context · 25 tok/s · 50% uptime
- **Ling 3.0 Flash** — 262K context · 85 tok/s · 99.95% uptime
- **Nemotron 3 Ultra** — 1M context · 31 tok/s · 96.15% uptime

The first completed exchange receives a concise generated title. Responses that echo title instructions are rejected, and a deterministic topic fallback prevents chats from remaining as “New chat.”

## Requirements

- Node.js 20 or newer
- LM Studio on the same machine for Gemma
- A server-side API key for the remote model routes
- `cloudflared` for the public tunnel

## Credential

Copy `.env.example` to `.env` and add the server-side key:

```env
OPENROUTER_API_KEY=your_key_here
OPENROUTER_HTTP_REFERER=https://your-public-hostname.example
OPENROUTER_APP_NAME=Aster
```

Only the key is required. The public hostname is optional attribution and can remain blank. Never expose `.env` as a static file or commit it to a repository.

## Run

```bash
npm start
```

The server listens on `0.0.0.0:3000`. Create a tunnel with:

```bash
cloudflared tunnel --url http://127.0.0.1:3000
```

For a stable hostname, point a named Cloudflare Tunnel at the same origin.

## Public-deployment warning

Aster has no built-in account system. Anyone who can reach the public hostname can consume model capacity and invoke enabled tools. Put the hostname behind Cloudflare Access, an identity-aware proxy, or another authentication layer unless unrestricted public use is intentional. The server applies per-IP request limits and caps concurrent generations, but those controls are not a substitute for authentication.

## Model routing

Deployment values live in `server/config.js`:

- port and bind address
- local model-service origin and model key
- remote model endpoint and model IDs
- token, timeout, history, concurrency, and rate limits
- web-tool and assistant-plan limits

The browser receives only display metadata and a generic availability flag.

## Tools and reasoning

Tool-capable models may call:

- `search_web` to find current public information
- `open_webpage` to read a public page
- `set_todos` to maintain the assistant's own visible execution plan

Tool activity is shown chronologically inside the thought process. Page reading blocks credentials in URLs, private addresses, loopback addresses, unsafe protocols, large bodies, and excessive redirects.

Reasoning is shown only when the model emits it. The interface handles streamed reasoning fields and `<think>...</think>` output.

## Browser storage

Conversation history, generated titles, selected model, expanded thought/tool state, assistant work plans, and interface preferences are stored in the browser. The app loads no third-party client assets and sends no analytics.

## Release checklist

Before publishing a deployment:

1. Copy `.env.example` to `.env` and set the server-side credential.
2. Put the public hostname behind an access layer unless anonymous use is intentional.
3. Run `npm run check` and start the server once locally.
4. Verify `/healthz`, model availability, streaming, title generation, and web-tool policy through the public hostname.
5. Keep the included favicon, app icons, manifest, and social preview image in `public/` so the deployed brand matches the interface.

The distributable archive intentionally excludes `.env`.
