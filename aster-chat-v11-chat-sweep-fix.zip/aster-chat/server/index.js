import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { lookup } from "node:dns/promises";
import net from "node:net";
import { CONFIG, MODEL_CATALOG } from "./config.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.resolve(__dirname, "../public");

const mimeTypes = new Map([
  [".html", "text/html; charset=utf-8"],
  [".css", "text/css; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".webmanifest", "application/manifest+json; charset=utf-8"],
  [".txt", "text/plain; charset=utf-8"],
  [".svg", "image/svg+xml"],
  [".png", "image/png"],
  [".ico", "image/x-icon"]
]);

const AGENT_TOOLS = [
  {
    type: "function",
    function: {
      name: "search_web",
      description: "Search the public web for current or uncertain information. Returns titles, snippets, and URLs.",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string", description: "A concise web search query." }
        },
        required: ["query"],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "open_webpage",
      description: "Read the main text of a public HTTP or HTTPS webpage. Use this after search_web when details are needed.",
      parameters: {
        type: "object",
        properties: {
          url: { type: "string", description: "The full public URL to read." }
        },
        required: ["url"],
        additionalProperties: false
      }
    }
  },
  {
    type: "function",
    function: {
      name: "set_todos",
      description: "Create or replace the assistant's pinned work checklist shown beside this chat. Track the AI's own execution steps for multi-step requests, not tasks for the user. Send the complete current list each time progress changes.",
      parameters: {
        type: "object",
        properties: {
          title: { type: "string", description: "A short checklist title." },
          items: {
            type: "array",
            minItems: 1,
            maxItems: 16,
            items: {
              type: "object",
              properties: {
                text: { type: "string", description: "A concrete task." },
                status: {
                  type: "string",
                  enum: ["pending", "in_progress", "done"],
                  description: "Current task status."
                }
              },
              required: ["text"],
              additionalProperties: false
            }
          }
        },
        required: ["title", "items"],
        additionalProperties: false
      }
    }
  }
];

function availableTools({ webAccess = true } = {}) {
  return AGENT_TOOLS.filter((tool) => {
    const name = tool.function.name;
    if (name === "set_todos") return CONFIG.ENABLE_TODO_TOOL;
    return CONFIG.ENABLE_WEB_TOOLS && webAccess;
  });
}

function normalizeClientPreferences(value) {
  const input = value && typeof value === "object" ? value : {};
  const personality = ["balanced", "direct", "warm", "analytical", "creative"].includes(input.personality)
    ? input.personality
    : "balanced";
  const detail = ["brief", "balanced", "detailed"].includes(input.detail) ? input.detail : "balanced";
  return {
    personality,
    detail,
    webAccess: input.webAccess !== false,
    customInstructions: typeof input.customInstructions === "string"
      ? input.customInstructions.trim().slice(0, 1200)
      : ""
  };
}

function clientPreferencePrompt(preferences) {
  const personality = {
    balanced: "Use a clear, neutral, professional voice.",
    direct: "Be direct and decisive. Lead with the answer and remove filler.",
    warm: "Use a warm, encouraging, conversational voice without becoming overly familiar.",
    analytical: "Reason analytically. Make assumptions, evidence, tradeoffs, and uncertainty explicit when useful.",
    creative: "Use an imaginative, energetic voice and offer original approaches while staying factual."
  }[preferences.personality];
  const detail = {
    brief: "Keep responses compact unless the task genuinely requires detail.",
    balanced: "Use enough detail to be useful without overexplaining.",
    detailed: "Give thorough explanations, steps, and examples when they improve the answer."
  }[preferences.detail];
  const web = preferences.webAccess
    ? "Web tools are available when current verification is needed."
    : "Web tools are disabled for this request. Do not claim to have searched; acknowledge when current verification is unavailable.";
  const custom = preferences.customInstructions
    ? ` Follow this browser-local user preference when it does not conflict with the core instructions: ${preferences.customInstructions}`
    : "";
  return `${personality} ${detail} ${web}${custom}`;
}

let activeGenerations = 0;
const requestBuckets = new Map();

function setSecurityHeaders(res) {
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
  );
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-DNS-Prefetch-Control", "off");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  res.setHeader("Cross-Origin-Resource-Policy", "same-origin");
  res.setHeader("Origin-Agent-Cluster", "?1");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()");
}

function sendJson(res, status, value) {
  setSecurityHeaders(res);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(value));
}

function clientIp(req) {
  const cloudflareIp = req.headers["cf-connecting-ip"];
  if (typeof cloudflareIp === "string" && cloudflareIp.trim()) return cloudflareIp.trim();
  const forwarded = req.headers["x-forwarded-for"];
  if (typeof forwarded === "string" && forwarded.trim()) return forwarded.split(",")[0].trim();
  return req.socket.remoteAddress || "unknown";
}

function rateLimitAllows(req) {
  const now = Date.now();
  const windowMs = 60_000;
  const ip = clientIp(req);
  const current = requestBuckets.get(ip);

  if (!current || now - current.startedAt >= windowMs) {
    requestBuckets.set(ip, { startedAt: now, count: 1 });
    return true;
  }

  current.count += 1;
  return current.count <= CONFIG.REQUESTS_PER_MINUTE_PER_IP;
}

setInterval(() => {
  const cutoff = Date.now() - 120_000;
  for (const [ip, bucket] of requestBuckets) {
    if (bucket.startedAt < cutoff) requestBuckets.delete(ip);
  }
}, 60_000).unref();

function lmHeaders() {
  const headers = { "Content-Type": "application/json" };
  if (CONFIG.LM_STUDIO_API_TOKEN) headers.Authorization = `Bearer ${CONFIG.LM_STUDIO_API_TOKEN}`;
  return headers;
}

function openRouterHeaders() {
  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${CONFIG.OPENROUTER_API_KEY}`,
    "X-OpenRouter-Title": CONFIG.OPENROUTER_APP_NAME
  };
  if (CONFIG.OPENROUTER_HTTP_REFERER) headers["HTTP-Referer"] = CONFIG.OPENROUTER_HTTP_REFERER;
  return headers;
}

function modelById(id) {
  const requested = typeof id === "string" ? id.trim() : "";
  return MODEL_CATALOG.find((model) => model.id === requested)
    || MODEL_CATALOG.find((model) => model.id === CONFIG.DEFAULT_MODEL_ID)
    || MODEL_CATALOG[0];
}

function publicModel(model, available, status) {
  return {
    id: model.id,
    label: model.label,
    shortLabel: model.shortLabel,
    context: model.contextLabel,
    speed: model.speedLabel,
    uptime: model.uptimeLabel,
    description: model.description,
    available: Boolean(available),
    status: available ? "Available" : "Unavailable"
  };
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);
  const text = await response.text();
  let value;
  try {
    value = text ? JSON.parse(text) : {};
  } catch {
    value = { raw: text };
  }
  if (!response.ok) {
    const error = new Error(`The model service returned HTTP ${response.status}`);
    error.status = response.status;
    error.details = value;
    throw error;
  }
  return value;
}

async function resolveModel(signal) {
  if (CONFIG.LM_STUDIO_MODEL !== "auto") return CONFIG.LM_STUDIO_MODEL;

  try {
    const native = await fetchJson(`${CONFIG.LM_STUDIO_ORIGIN}/api/v1/models`, {
      headers: lmHeaders(),
      signal
    });
    const llms = Array.isArray(native.models)
      ? native.models.filter((model) => model?.type === "llm" && typeof model.key === "string")
      : [];
    const loaded = llms.find((model) => Array.isArray(model.loaded_instances) && model.loaded_instances.length > 0);
    if (loaded) return loaded.key;
    if (llms[0]) return llms[0].key;
  } catch {
    // Older LM Studio builds may not expose the native v1 model list.
  }

  const compatible = await fetchJson(`${CONFIG.LM_STUDIO_ORIGIN}/v1/models`, {
    headers: lmHeaders(),
    signal
  });
  const first = Array.isArray(compatible.data)
    ? compatible.data.find((model) => typeof model?.id === "string")
    : null;
  if (!first) throw new Error("No language model is currently available.");
  return first.id;
}

async function readJsonBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > CONFIG.MAX_BODY_BYTES) {
      const error = new Error("Request body is too large.");
      error.statusCode = 413;
      throw error;
    }
    chunks.push(chunk);
  }
  const text = Buffer.concat(chunks).toString("utf8");
  try {
    return JSON.parse(text || "{}");
  } catch {
    const error = new Error("Request body must be valid JSON.");
    error.statusCode = 400;
    throw error;
  }
}

function normalizeMessages(input) {
  if (!Array.isArray(input)) return null;
  const allowedRoles = new Set(["user", "assistant"]);
  const messages = input
    .filter(
      (item) =>
        item &&
        allowedRoles.has(item.role) &&
        typeof item.content === "string" &&
        item.content.trim().length > 0
    )
    .map((item) => ({
      role: item.role,
      content: item.content.trim().slice(0, 80_000)
    }))
    .slice(-CONFIG.MAX_HISTORY_MESSAGES);
  return messages.length ? messages : null;
}

function writeSse(res, event, payload) {
  res.write(`event: ${event}\n`);
  res.write(`data: ${JSON.stringify(payload)}\n\n`);
}

function upstreamMessage(details, fallback = "The inference provider could not complete the request.") {
  if (typeof details?.error?.message === "string") return details.error.message;
  if (typeof details?.message === "string") return details.message;
  if (typeof details?.raw === "string" && details.raw.trim()) return details.raw.trim().slice(0, 500);
  return fallback;
}

function decodeHtmlEntities(value) {
  const named = {
    amp: "&",
    lt: "<",
    gt: ">",
    quot: '"',
    apos: "'",
    nbsp: " ",
    ndash: "–",
    mdash: "—",
    hellip: "…"
  };
  return String(value)
    .replace(/&#(\d+);/g, (_match, code) => String.fromCodePoint(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_match, code) => String.fromCodePoint(parseInt(code, 16)))
    .replace(/&([a-z]+);/gi, (match, name) => named[name.toLowerCase()] ?? match);
}

function stripTags(value) {
  return decodeHtmlEntities(
    String(value)
      .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
      .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
      .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, " ")
      .replace(/<svg\b[^>]*>[\s\S]*?<\/svg>/gi, " ")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/(p|div|section|article|li|h[1-6]|tr)>/gi, "\n")
      .replace(/<[^>]+>/g, " ")
  )
    .replace(/[ \t]+/g, " ")
    .replace(/\n[ \t]+/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function isPrivateAddress(address) {
  if (!address) return true;
  const lower = address.toLowerCase();

  if (net.isIPv4(lower)) {
    const [a, b] = lower.split(".").map(Number);
    return (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127) ||
      a >= 224
    );
  }

  if (net.isIPv6(lower)) {
    if (lower === "::" || lower === "::1") return true;
    if (lower.startsWith("fc") || lower.startsWith("fd")) return true;
    if (/^fe[89ab]/.test(lower)) return true;
    if (lower.startsWith("ff")) return true;
    const mapped = lower.match(/::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isPrivateAddress(mapped[1]);
  }

  return false;
}

async function assertPublicUrl(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error("The tool received an invalid URL.");
  }
  if (!["http:", "https:"].includes(parsed.protocol)) {
    throw new Error("Only public HTTP and HTTPS URLs can be opened.");
  }
  if (!parsed.hostname || parsed.username || parsed.password) {
    throw new Error("The URL is not allowed.");
  }
  const hostname = parsed.hostname.toLowerCase();
  if (hostname === "localhost" || hostname.endsWith(".local") || hostname.endsWith(".internal")) {
    throw new Error("Local and private network addresses cannot be opened.");
  }
  const addresses = await lookup(hostname, { all: true, verbatim: true });
  if (!addresses.length || addresses.some((entry) => isPrivateAddress(entry.address))) {
    throw new Error("Local and private network addresses cannot be opened.");
  }
  return parsed;
}

async function fetchPublicUrl(rawUrl, signal, redirects = 0) {
  if (redirects > 4) throw new Error("The webpage redirected too many times.");
  const parsed = await assertPublicUrl(rawUrl);
  const response = await fetch(parsed, {
    signal,
    redirect: "manual",
    headers: {
      "User-Agent": "Mozilla/5.0 (compatible; Aster/9.0)",
      Accept: "text/html,application/xhtml+xml,text/plain,application/json;q=0.8,*/*;q=0.2"
    }
  });

  if ([301, 302, 303, 307, 308].includes(response.status)) {
    const location = response.headers.get("location");
    if (!location) throw new Error("The webpage returned an invalid redirect.");
    return fetchPublicUrl(new URL(location, parsed).toString(), signal, redirects + 1);
  }
  return { response, finalUrl: parsed.toString() };
}

async function readResponseLimited(response, maxBytes) {
  if (!response.body) return "";
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) {
      chunks.push(value.slice(0, Math.max(0, maxBytes - (total - value.byteLength))));
      await reader.cancel();
      break;
    }
    chunks.push(value);
  }
  return Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))).toString("utf8");
}

function unwrapDuckDuckGoUrl(rawHref) {
  const href = decodeHtmlEntities(rawHref);
  try {
    const parsed = new URL(href, "https://html.duckduckgo.com");
    const redirected = parsed.searchParams.get("uddg");
    return redirected ? decodeURIComponent(redirected) : parsed.toString();
  } catch {
    return href;
  }
}

function parseDuckDuckGo(html, limit) {
  const results = [];
  const resultRegex = /<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let match;
  while ((match = resultRegex.exec(html)) && results.length < limit) {
    const tail = html.slice(resultRegex.lastIndex, resultRegex.lastIndex + 2200);
    const snippetMatch = tail.match(/class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/(?:a|div|span)>/i);
    const title = stripTags(match[2]);
    const url = unwrapDuckDuckGoUrl(match[1]);
    const snippet = snippetMatch ? stripTags(snippetMatch[1]) : "";
    if (title && /^https?:\/\//i.test(url)) results.push({ title, url, snippet });
  }
  return results;
}

async function wikipediaFallback(query, signal, limit) {
  const endpoint = new URL("https://en.wikipedia.org/w/api.php");
  endpoint.searchParams.set("action", "query");
  endpoint.searchParams.set("list", "search");
  endpoint.searchParams.set("srsearch", query);
  endpoint.searchParams.set("utf8", "1");
  endpoint.searchParams.set("format", "json");
  endpoint.searchParams.set("srlimit", String(limit));
  const response = await fetch(endpoint, { signal, headers: { "User-Agent": "Aster/9.0" } });
  if (!response.ok) return [];
  const data = await response.json();
  return Array.isArray(data?.query?.search)
    ? data.query.search.map((item) => ({
        title: item.title,
        url: `https://en.wikipedia.org/wiki/${encodeURIComponent(item.title.replaceAll(" ", "_"))}`,
        snippet: stripTags(item.snippet || "")
      }))
    : [];
}

async function searchWeb(query, parentSignal) {
  const clean = String(query || "").replace(/\s+/g, " ").trim().slice(0, 500);
  if (!clean) throw new Error("search_web requires a non-empty query.");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), CONFIG.WEB_FETCH_TIMEOUT_MS);
  const abort = () => controller.abort();
  parentSignal?.addEventListener("abort", abort, { once: true });
  try {
    let results = [];
    try {
      const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(clean)}`;
      const response = await fetch(url, {
        signal: controller.signal,
        headers: {
          "User-Agent": "Mozilla/5.0 (compatible; Aster/9.0)",
          Accept: "text/html"
        }
      });
      const html = response.ok ? await readResponseLimited(response, 900_000) : "";
      results = parseDuckDuckGo(html, CONFIG.WEB_SEARCH_RESULTS);
    } catch {
      // Try the fallback below.
    }

    if (!results.length) {
      try {
        results = await wikipediaFallback(clean, controller.signal, CONFIG.WEB_SEARCH_RESULTS);
      } catch {
        // Return a clean no-results tool response rather than breaking the chat.
      }
    }
    if (!results.length) return { content: `No useful web results were found for: ${clean}`, count: 0 };

    const content = results
      .map((item, index) => `${index + 1}. ${item.title}\nURL: ${item.url}${item.snippet ? `\nSnippet: ${item.snippet}` : ""}`)
      .join("\n\n");
    return { content, count: results.length };
  } finally {
    clearTimeout(timeout);
    parentSignal?.removeEventListener("abort", abort);
  }
}

function extractPageTitle(html) {
  const match = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return match ? stripTags(match[1]).slice(0, 180) : "";
}

async function openWebpage(rawUrl, parentSignal) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), CONFIG.WEB_FETCH_TIMEOUT_MS);
  const abort = () => controller.abort();
  parentSignal?.addEventListener("abort", abort, { once: true });
  try {
    const { response, finalUrl } = await fetchPublicUrl(rawUrl, controller.signal);
    if (!response.ok) throw new Error(`The webpage returned HTTP ${response.status}.`);
    const contentType = (response.headers.get("content-type") || "").toLowerCase();
    if (!/(text\/html|text\/plain|application\/json|application\/xhtml\+xml)/.test(contentType)) {
      throw new Error("The URL did not return readable text.");
    }
    const raw = await readResponseLimited(response, CONFIG.WEB_MAX_RESPONSE_BYTES);
    const title = contentType.includes("html") ? extractPageTitle(raw) : "";
    const text = contentType.includes("html") ? stripTags(raw) : raw.replace(/\s+/g, " ").trim();
    const excerpt = text.slice(0, CONFIG.WEB_MAX_EXTRACTED_CHARS);
    if (!excerpt) throw new Error("No readable text was found on the webpage.");
    return {
      content: `Title: ${title || "Untitled page"}\nURL: ${finalUrl}\n\n${excerpt}`,
      title: title || new URL(finalUrl).hostname,
      finalUrl
    };
  } finally {
    clearTimeout(timeout);
    parentSignal?.removeEventListener("abort", abort);
  }
}

function parseToolArguments(raw) {
  if (raw && typeof raw === "object") return raw;
  if (typeof raw !== "string" || !raw.trim()) return {};
  try {
    return JSON.parse(raw);
  } catch {
    const first = raw.indexOf("{");
    const last = raw.lastIndexOf("}");
    if (first !== -1 && last > first) {
      try {
        return JSON.parse(raw.slice(first, last + 1));
      } catch {
        // fall through
      }
    }
    return {};
  }
}

function describeToolCall(name, args) {
  if (name === "search_web") {
    const query = String(args.query || "").replace(/\s+/g, " ").trim().slice(0, 120);
    return { label: "Searching the web", detail: query };
  }
  if (name === "open_webpage") {
    let detail = String(args.url || "").slice(0, 160);
    try {
      detail = new URL(detail).hostname;
    } catch {
      // Keep raw detail.
    }
    return { label: "Reading a web page", detail };
  }
  if (name === "set_todos") {
    const title = String(args.title || "Tasks").replace(/\s+/g, " ").trim().slice(0, 80);
    const count = Array.isArray(args.items) ? args.items.length : 0;
    return { label: "Updating tasks", detail: title || `${count} task${count === 1 ? "" : "s"}` };
  }
  return { label: "Using a tool", detail: name };
}


function buildTodoPayload(args) {
  const rawItems = Array.isArray(args.items) ? args.items : [];
  const items = rawItems
    .filter((item) => item && typeof item.text === "string" && item.text.trim())
    .slice(0, 16)
    .map((item, index) => ({
      id: `task_${Date.now().toString(36)}_${index}_${Math.random().toString(36).slice(2, 6)}`,
      text: item.text.replace(/\s+/g, " ").trim().slice(0, 300),
      status: ["pending", "in_progress", "done"].includes(item.status) ? item.status : "pending"
    }));
  if (!items.length) throw new Error("set_todos requires at least one task.");
  return {
    id: `todo_${Date.now().toString(36)}`,
    title: String(args.title || "Tasks").replace(/\s+/g, " ").trim().slice(0, 80) || "Tasks",
    items,
    updatedAt: Date.now()
  };
}

async function executeToolCall(call, signal) {
  const name = call?.function?.name || "";
  const args = parseToolArguments(call?.function?.arguments);
  if (name === "search_web") {
    const result = await searchWeb(args.query, signal);
    return {
      content: result.content,
      detail: result.count ? `${result.count} result${result.count === 1 ? "" : "s"}` : "No results"
    };
  }
  if (name === "open_webpage") {
    const result = await openWebpage(args.url, signal);
    return { content: result.content, detail: result.title };
  }
  if (name === "set_todos") {
    const todo = buildTodoPayload(args);
    const summary = todo.items
      .map((item, index) => `${index + 1}. [${item.status}] ${item.text}`)
      .join("\n");
    return {
      content: `Pinned checklist updated: ${todo.title}\n${summary}`,
      detail: `${todo.items.length} task${todo.items.length === 1 ? "" : "s"}`,
      todo
    };
  }
  return { content: `Tool error: unknown tool "${name}".`, detail: "Unavailable" };
}

function extractTextDelta(value) {
  if (typeof value === "string") return value;
  if (Array.isArray(value)) {
    return value
      .map((part) => {
        if (typeof part === "string") return part;
        if (typeof part?.text === "string") return part.text;
        if (typeof part?.content === "string") return part.content;
        return "";
      })
      .join("");
  }
  return "";
}

function extractReasoningDetails(value) {
  if (!Array.isArray(value)) return "";
  return value.map((item) => {
    if (!item || typeof item !== "object") return "";
    if (typeof item.text === "string") return item.text;
    if (typeof item.summary === "string") return item.summary;
    return "";
  }).join("");
}

function matchingSuffixLength(value, token) {
  const max = Math.min(value.length, token.length - 1);
  for (let length = max; length > 0; length -= 1) {
    if (token.startsWith(value.slice(-length))) return length;
  }
  return 0;
}

class ThinkTagRouter {
  constructor(onContent, onReasoning) {
    this.onContent = onContent;
    this.onReasoning = onReasoning;
    this.mode = "content";
    this.pending = "";
  }

  push(chunk) {
    if (!chunk) return;
    this.pending += chunk;
    this.drain(false);
  }

  drain(flush) {
    while (this.pending) {
      const token = this.mode === "content" ? "<think>" : "</think>";
      const index = this.pending.indexOf(token);
      if (index !== -1) {
        const text = this.pending.slice(0, index);
        if (text) this.emit(text);
        this.pending = this.pending.slice(index + token.length);
        this.mode = this.mode === "content" ? "reasoning" : "content";
        continue;
      }

      if (flush) {
        this.emit(this.pending);
        this.pending = "";
        break;
      }

      const keep = matchingSuffixLength(this.pending, token);
      const safeLength = this.pending.length - keep;
      if (safeLength > 0) {
        this.emit(this.pending.slice(0, safeLength));
        this.pending = this.pending.slice(safeLength);
      }
      break;
    }
  }

  emit(text) {
    if (this.mode === "reasoning") this.onReasoning(text);
    else this.onContent(text);
  }

  flush() {
    this.drain(true);
  }
}

async function streamCompletion({ modelConfig, model, messages, signal, useTools, toolset, onContent, onReasoning }) {
  const body = {
    model,
    messages,
    temperature: CONFIG.TEMPERATURE,
    top_p: CONFIG.TOP_P,
    max_tokens: CONFIG.MAX_TOKENS,
    stream: true
  };
  if (modelConfig.provider === "openrouter" && modelConfig.reasoning) {
    body.reasoning = { enabled: true, exclude: false };
  }
  if (useTools) {
    body.tools = Array.isArray(toolset) ? toolset : availableTools();
    body.tool_choice = "auto";
  }

  const endpoint = modelConfig.provider === "openrouter"
    ? `${CONFIG.OPENROUTER_ORIGIN}/chat/completions`
    : `${CONFIG.LM_STUDIO_ORIGIN}/v1/chat/completions`;
  const upstream = await fetch(endpoint, {
    method: "POST",
    headers: modelConfig.provider === "openrouter" ? openRouterHeaders() : lmHeaders(),
    signal,
    body: JSON.stringify(body)
  });

  if (!upstream.ok || !upstream.body) {
    const text = await upstream.text();
    let details;
    try {
      details = JSON.parse(text);
    } catch {
      details = { raw: text };
    }
    const error = new Error(upstreamMessage(
      details,
      "The selected model could not complete the request."
    ));
    error.statusCode = upstream.status || 502;
    const diagnostic = `${error.message} ${text}`.toLowerCase();
    error.toolUnsupported = useTools && [400, 404, 422].includes(upstream.status) && /(tool|function|template)/.test(diagnostic);
    throw error;
  }

  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  const toolCalls = new Map();
  const router = new ThinkTagRouter(onContent, onReasoning);
  let rawContent = "";
  let reasoning = "";
  const reasoningDetails = [];
  let visibleContent = "";
  let buffer = "";
  let finishReason = null;

  const emitContent = (text) => {
    if (!text) return;
    visibleContent += text;
    onContent(text);
  };
  const emitReasoning = (text) => {
    if (!text) return;
    reasoning += text;
    onReasoning(text);
  };
  router.onContent = emitContent;
  router.onReasoning = emitReasoning;

  const processPacket = (packet) => {
    const choice = packet?.choices?.[0];
    const delta = choice?.delta || {};
    if (packet?.error) {
      const error = new Error(upstreamMessage(packet, "The provider stream ended with an error."));
      error.statusCode = Number(packet.error.code) || 502;
      throw error;
    }

    const detailDelta = Array.isArray(delta.reasoning_details) ? delta.reasoning_details : [];
    if (detailDelta.length) reasoningDetails.push(...detailDelta);
    const reasoningDelta = extractTextDelta(delta.reasoning_content ?? delta.reasoning ?? delta.analysis)
      || extractReasoningDetails(detailDelta);
    if (reasoningDelta) emitReasoning(reasoningDelta);

    const contentDelta = extractTextDelta(delta.content);
    if (contentDelta) {
      rawContent += contentDelta;
      router.push(contentDelta);
    }

    const streamedCalls = Array.isArray(delta.tool_calls) ? delta.tool_calls : [];
    for (const partial of streamedCalls) {
      const index = Number.isInteger(partial.index) ? partial.index : toolCalls.size;
      const current = toolCalls.get(index) || {
        id: "",
        type: "function",
        function: { name: "", arguments: "" }
      };
      if (typeof partial.id === "string" && !current.id) current.id = partial.id;
      if (typeof partial.type === "string") current.type = partial.type;
      if (typeof partial.function?.name === "string") current.function.name += partial.function.name;
      if (typeof partial.function?.arguments === "string") current.function.arguments += partial.function.arguments;
      toolCalls.set(index, current);
    }

    if (delta.function_call) {
      const current = toolCalls.get(0) || {
        id: `call_${Date.now().toString(36)}`,
        type: "function",
        function: { name: "", arguments: "" }
      };
      if (typeof delta.function_call.name === "string") current.function.name += delta.function_call.name;
      if (typeof delta.function_call.arguments === "string") current.function.arguments += delta.function_call.arguments;
      toolCalls.set(0, current);
    }

    if (choice?.finish_reason) finishReason = choice.finish_reason;
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, "\n");

    let boundary;
    while ((boundary = buffer.indexOf("\n\n")) !== -1) {
      const block = buffer.slice(0, boundary);
      buffer = buffer.slice(boundary + 2);
      const dataLines = block
        .split("\n")
        .filter((line) => line.startsWith("data:"))
        .map((line) => line.slice(5).trim());
      for (const data of dataLines) {
        if (!data || data === "[DONE]") continue;
        let packet;
        try {
          packet = JSON.parse(data);
        } catch {
          continue;
        }
        processPacket(packet);
      }
    }
  }

  router.flush();
  return {
    content: visibleContent,
    rawContent,
    reasoning,
    reasoningDetails,
    toolCalls: [...toolCalls.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([, call], index) => ({
        ...call,
        id: call.id || `call_${Date.now().toString(36)}_${index}`
      }))
      .filter((call) => call.function.name),
    finishReason
  };
}

function sanitizeGeneratedTitle(value) {
  let title = String(value || "")
    .replace(/<think>[\s\S]*?<\/think>/gi, " ")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/^\s*(?:title|chat title)\s*:\s*/i, "")
    .replace(/[\r\n]+/g, " ")
    .replace(/^[\s"'`*_#-]+|[\s"'`*_#.!?:;-]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!title) return "";
  const words = title.split(" ").filter(Boolean).slice(0, 8);
  title = words.join(" ");
  if (title.length > 64) title = `${title.slice(0, 63).trim()}…`;
  return title;
}


const TITLE_FALLBACK_STOP_WORDS = new Set([
  "a", "an", "and", "are", "as", "at", "be", "been", "but", "by", "can", "could", "also", "do", "does", "either", "for", "from", "have", "help", "here", "how", "i", "in", "into", "is", "it", "just", "like", "look", "looks", "make", "me", "my", "need", "of", "on", "or", "our", "please", "really", "see", "should", "still", "that", "the", "these", "thing", "things", "this", "those", "to", "use", "want", "with", "would", "you", "your"
]);

function fallbackConversationTitle(value) {
  const cleaned = String(value || "")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/https?:\/\/\S+/gi, " ")
    .replace(/\b(?:the user|user wants?|assistant|conversation|chat title|concise title)\b/gi, " ")
    .replace(/[^\p{L}\p{N}+#._'-]+/gu, " ")
    .trim();
  const tokens = (cleaned.match(/[\p{L}\p{N}][\p{L}\p{N}+#._'-]*/gu) || []).map((word) => word.replace(/^[._'-]+|[._'-]+$/g, "")).filter(Boolean);
  const meaningful = tokens.filter((word) => !TITLE_FALLBACK_STOP_WORDS.has(word.toLowerCase()));
  const picked = (meaningful.length ? meaningful : tokens).slice(0, 6);
  if (!picked.length) return "Untitled conversation";
  return picked.map((word) => {
    if (/^[A-Z0-9+#._-]{2,}$/.test(word)) return word;
    return word.charAt(0).toUpperCase() + word.slice(1);
  }).join(" ").slice(0, 64);
}

function usableGeneratedTitle(value) {
  const title = sanitizeGeneratedTitle(value);
  if (!title) return "";
  if (/\b(?:the user wants?|the user asks?|concise title|conversation title|chat title|return only|assistant response|system prompt|this conversation)\b/i.test(title)) return "";
  return title;
}

function normalizedTitleTerm(value) {
  let term = String(value || "").toLowerCase().replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
  if (term.length > 5) term = term.replace(/(?:ing|ers?|ed|es|s)$/i, "");
  return term;
}

function generatedTitleMatchesSource(title, source) {
  const titleTerms = [...new Set((String(title).match(/[\p{L}\p{N}]+/gu) || [])
    .map(normalizedTitleTerm).filter((term) => term && !TITLE_FALLBACK_STOP_WORDS.has(term)))];
  const sourceTerms = new Set((String(source).match(/[\p{L}\p{N}]+/gu) || [])
    .map(normalizedTitleTerm).filter((term) => term && !TITLE_FALLBACK_STOP_WORDS.has(term)));
  if (!titleTerms.length || !sourceTerms.size) return false;
  const overlap = titleTerms.filter((term) => sourceTerms.has(term)).length;
  return overlap >= Math.min(2, titleTerms.length);
}

async function generateTitle({ modelConfig, model, user, assistant, signal }) {
  const endpoint = modelConfig.provider === "openrouter"
    ? `${CONFIG.OPENROUTER_ORIGIN}/chat/completions`
    : `${CONFIG.LM_STUDIO_ORIGIN}/v1/chat/completions`;
  const upstream = await fetch(endpoint, {
    method: "POST",
    headers: modelConfig.provider === "openrouter" ? openRouterHeaders() : lmHeaders(),
    signal,
    body: JSON.stringify({
      model,
      stream: false,
      temperature: 0.2,
      top_p: 0.9,
      max_tokens: 28,
      messages: [
        {
          role: "system",
          content: "Write a concise title for this conversation. Use 3 to 7 words. Return only the title, with no quotes, label, markdown, or ending punctuation. Describe the actual topic rather than copying the opening words."
        },
        {
          role: "user",
          content: `User request:\n${user.slice(0, 5000)}\n\nAssistant response:\n${assistant.slice(0, 5000)}`
        }
      ]
    })
  });
  const text = await upstream.text();
  let payload = {};
  try { payload = text ? JSON.parse(text) : {}; } catch { payload = {}; }
  if (!upstream.ok) {
    const error = new Error("Could not generate a conversation title.");
    error.statusCode = upstream.status || 502;
    throw error;
  }
  const content = payload?.choices?.[0]?.message?.content;
  return usableGeneratedTitle(content);
}

async function handleTitle(req, res) {
  if (!rateLimitAllows(req)) {
    sendJson(res, 429, { error: "Too many requests. Wait a moment and try again." });
    return;
  }
  if (activeGenerations >= CONFIG.MAX_CONCURRENT_GENERATIONS) {
    sendJson(res, 503, { error: "The model queue is busy. Try again shortly." });
    return;
  }

  let body;
  try {
    body = await readJsonBody(req);
  } catch (error) {
    sendJson(res, error.statusCode || 400, { error: error.message });
    return;
  }
  const user = typeof body.user === "string" ? body.user.trim().slice(0, 5000) : "";
  const assistant = typeof body.assistant === "string" ? body.assistant.trim().slice(0, 5000) : "";
  if (!user || !assistant) {
    sendJson(res, 400, { error: "Conversation text is required." });
    return;
  }
  const selectedModel = modelById(body.model);
  if (!selectedModel || (typeof body.model === "string" && body.model && selectedModel.id !== body.model)) {
    sendJson(res, 400, { error: "The selected model is not available in this build." });
    return;
  }
  if (selectedModel.provider === "openrouter" && !CONFIG.OPENROUTER_API_KEY) {
    sendJson(res, 503, { error: "This model is currently unavailable." });
    return;
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25_000);
  const abortUpstream = () => controller.abort();
  res.once("close", abortUpstream);
  activeGenerations += 1;
  try {
    const model = selectedModel.provider === "lmstudio"
      ? await resolveModel(controller.signal)
      : selectedModel.upstreamModel;
    const generated = await generateTitle({
      modelConfig: selectedModel,
      model,
      user,
      assistant,
      signal: controller.signal
    });
    sendJson(res, 200, { title: generated && generatedTitleMatchesSource(generated, user) ? generated : fallbackConversationTitle(user) });
  } catch {
    if (!res.headersSent) sendJson(res, 200, { title: fallbackConversationTitle(user) });
  } finally {
    clearTimeout(timeout);
    res.off("close", abortUpstream);
    activeGenerations = Math.max(0, activeGenerations - 1);
  }
}

async function handleChat(req, res) {
  if (!rateLimitAllows(req)) {
    sendJson(res, 429, { error: "Too many requests. Wait a moment and try again." });
    return;
  }
  if (activeGenerations >= CONFIG.MAX_CONCURRENT_GENERATIONS) {
    sendJson(res, 503, { error: "The model queue is busy. Try again shortly." });
    return;
  }

  let body;
  try {
    body = await readJsonBody(req);
  } catch (error) {
    sendJson(res, error.statusCode || 400, { error: error.message });
    return;
  }

  const messages = normalizeMessages(body.messages);
  if (!messages) {
    sendJson(res, 400, { error: "At least one non-empty chat message is required." });
    return;
  }

  const selectedModel = modelById(body.model);
  if (!selectedModel || (typeof body.model === "string" && body.model && selectedModel.id !== body.model)) {
    sendJson(res, 400, { error: "The selected model is not available in this build." });
    return;
  }
  if (selectedModel.provider === "openrouter" && !CONFIG.OPENROUTER_API_KEY) {
    sendJson(res, 503, { error: "This model is currently unavailable." });
    return;
  }

  const clientPreferences = normalizeClientPreferences(body.preferences);
  const requestTools = availableTools({ webAccess: clientPreferences.webAccess });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(new Error("Inference timed out.")), CONFIG.REQUEST_TIMEOUT_MS);
  const abortUpstream = () => controller.abort(new Error("Client disconnected."));
  res.once("close", abortUpstream);

  activeGenerations += 1;
  let streamStarted = false;

  try {
    const model = selectedModel.provider === "lmstudio"
      ? await resolveModel(controller.signal)
      : selectedModel.upstreamModel;

    setSecurityHeaders(res);
    res.writeHead(200, {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no"
    });
    res.flushHeaders?.();
    streamStarted = true;
    writeSse(res, "ready", { ok: true });

    const today = new Date().toISOString().slice(0, 10);
    const currentTodo = body.todo && typeof body.todo === "object" && Array.isArray(body.todo.items)
      ? body.todo.items
          .filter((item) => item && typeof item.text === "string")
          .slice(0, 16)
          .map((item, index) => `${index + 1}. [${item.status || "pending"}] ${item.text.slice(0, 300)}`)
          .join("\n")
      : "";
    const todoContext = currentTodo
      ? ` Your current pinned work checklist:\n${currentTodo}\nCall set_todos with the complete updated checklist whenever your visible execution progress changes.`
      : " Use set_todos for genuinely multi-step work that benefits from showing your own execution progress; do not create one for a trivial single-answer request or for tasks the user should perform.";
    const workingMessages = [
      { role: "system", content: `${CONFIG.SYSTEM_PROMPT} ${clientPreferencePrompt(clientPreferences)} Today is ${today}.${todoContext}` },
      ...messages
    ];
    let useTools = requestTools.length > 0;
    let completed = false;

    for (let round = 0; round <= CONFIG.MAX_TOOL_ROUNDS; round += 1) {
      let result;
      try {
        result = await streamCompletion({
          modelConfig: selectedModel,
          model,
          messages: workingMessages,
          signal: controller.signal,
          useTools,
          toolset: requestTools,
          onContent: (text) => writeSse(res, "token", { text }),
          onReasoning: (text) => writeSse(res, "reasoning", { text })
        });
      } catch (error) {
        if (error.toolUnsupported && useTools) {
          useTools = false;
          result = await streamCompletion({
            modelConfig: selectedModel,
            model,
            messages: workingMessages,
            signal: controller.signal,
            useTools: false,
            toolset: requestTools,
            onContent: (text) => writeSse(res, "token", { text }),
            onReasoning: (text) => writeSse(res, "reasoning", { text })
          });
        } else {
          throw error;
        }
      }

      if (!result.toolCalls.length) {
        completed = true;
        break;
      }

      const assistantToolMessage = {
        role: "assistant",
        content: result.content || null,
        tool_calls: result.toolCalls
      };
      if (result.reasoningDetails?.length) assistantToolMessage.reasoning_details = result.reasoningDetails;
      else if (result.reasoning) assistantToolMessage.reasoning = result.reasoning;
      workingMessages.push(assistantToolMessage);

      for (const call of result.toolCalls) {
        const args = parseToolArguments(call.function.arguments);
        const description = describeToolCall(call.function.name, args);
        writeSse(res, "tool_start", {
          id: call.id,
          name: call.function.name,
          label: description.label,
          detail: description.detail
        });

        let toolResult;
        try {
          toolResult = await executeToolCall(call, controller.signal);
        } catch (error) {
          toolResult = {
            content: `Tool error: ${error.message || "The web request failed."}`,
            detail: "Failed"
          };
        }

        if (toolResult.todo) {
          writeSse(res, "todo_update", { todo: toolResult.todo });
        }
        writeSse(res, "tool_result", {
          id: call.id,
          name: call.function.name,
          detail: toolResult.detail,
          result: toolResult.content.slice(0, CONFIG.WEB_MAX_EXTRACTED_CHARS + 2000)
        });
        workingMessages.push({
          role: "tool",
          tool_call_id: call.id,
          name: call.function.name,
          content: toolResult.content.slice(0, CONFIG.WEB_MAX_EXTRACTED_CHARS + 2000)
        });
      }

      if (round === CONFIG.MAX_TOOL_ROUNDS) {
        workingMessages.push({
          role: "system",
          content: "The tool-call limit has been reached. Answer the user now using the information already gathered."
        });
        await streamCompletion({
          modelConfig: selectedModel,
          model,
          messages: workingMessages,
          signal: controller.signal,
          useTools: false,
          onContent: (text) => writeSse(res, "token", { text }),
          onReasoning: (text) => writeSse(res, "reasoning", { text })
        });
        completed = true;
        break;
      }
    }

    writeSse(res, "done", { ok: completed });
    res.end();
  } catch (error) {
    const disconnected = controller.signal.aborted && res.destroyed;
    if (disconnected) return;

    const message = controller.signal.aborted
      ? "The request was stopped."
      : error?.message || "The selected model is unavailable.";

    if (!streamStarted) {
      sendJson(res, error.statusCode || 502, { error: message });
    } else if (!res.writableEnded) {
      writeSse(res, "error", { error: message });
      res.end();
    }
  } finally {
    clearTimeout(timeout);
    res.off("close", abortUpstream);
    activeGenerations = Math.max(0, activeGenerations - 1);
  }
}

async function getModelStatuses() {
  let localReady = false;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2500);
  try {
    await resolveModel(controller.signal);
    localReady = true;
  } catch {
    // Availability is intentionally reported without exposing deployment details.
  } finally {
    clearTimeout(timeout);
  }

  return MODEL_CATALOG.map((model) => {
    if (model.provider === "lmstudio") return publicModel(model, localReady);
    return publicModel(model, Boolean(CONFIG.OPENROUTER_API_KEY));
  });
}

async function handleModels(_req, res) {
  const models = await getModelStatuses();
  sendJson(res, 200, { defaultModel: CONFIG.DEFAULT_MODEL_ID, models });
}

async function handleStatus(_req, res) {
  const models = await getModelStatuses();
  sendJson(res, 200, { ready: models.some((model) => model.available), models });
}

function handleHealth(_req, res) {
  sendJson(res, 200, { ok: true, service: "aster", version: "11.0.0" });
}

function staticCacheControl(filePath) {
  const extension = path.extname(filePath).toLowerCase();
  if (extension === ".html" || extension === ".webmanifest" || extension === ".txt") {
    return "no-store, max-age=0";
  }
  if ([".css", ".js", ".svg", ".png", ".ico"].includes(extension)) {
    return "public, max-age=86400, stale-while-revalidate=604800";
  }
  return "no-store, max-age=0";
}

async function serveStatic(req, res) {
  const requestUrl = new URL(req.url, "http://localhost");
  let pathname = decodeURIComponent(requestUrl.pathname);
  if (pathname === "/") pathname = "/index.html";

  const candidate = path.resolve(publicDir, `.${pathname}`);
  if (!candidate.startsWith(publicDir + path.sep)) {
    sendJson(res, 403, { error: "Forbidden" });
    return;
  }

  try {
    const fileStat = await stat(candidate);
    if (!fileStat.isFile()) throw new Error("Not a file");
    const data = await readFile(candidate);
    setSecurityHeaders(res);
    const cacheControl = staticCacheControl(candidate);
    const headers = {
      "Content-Type": mimeTypes.get(path.extname(candidate).toLowerCase()) || "application/octet-stream",
      "Cache-Control": cacheControl
    };
    if (cacheControl.startsWith("no-store")) {
      headers.Pragma = "no-cache";
      headers.Expires = "0";
    }
    res.writeHead(200, headers);
    if (req.method === "HEAD") res.end();
    else res.end(data);
  } catch {
    if (path.extname(pathname)) {
      sendJson(res, 404, { error: "Not found" });
      return;
    }
    try {
      const data = await readFile(path.join(publicDir, "index.html"));
      setSecurityHeaders(res);
      res.writeHead(200, {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0"
      });
      if (req.method === "HEAD") res.end();
      else res.end(data);
    } catch {
      sendJson(res, 404, { error: "Not found" });
    }
  }
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "POST" && req.url === "/api/chat") {
      await handleChat(req, res);
      return;
    }
    if (req.method === "POST" && req.url === "/api/title") {
      await handleTitle(req, res);
      return;
    }
    if (req.method === "GET" && req.url === "/api/models") {
      await handleModels(req, res);
      return;
    }
    if (req.method === "GET" && req.url === "/api/status") {
      await handleStatus(req, res);
      return;
    }
    if ((req.method === "GET" || req.method === "HEAD") && req.url === "/healthz") {
      handleHealth(req, res);
      return;
    }
    if (req.method === "GET" || req.method === "HEAD") {
      await serveStatic(req, res);
      return;
    }
    sendJson(res, 405, { error: "Method not allowed" });
  } catch (error) {
    if (!res.headersSent) sendJson(res, 500, { error: "Unexpected server error" });
    else res.destroy(error);
  }
});

server.keepAliveTimeout = 75_000;
server.headersTimeout = 80_000;
server.requestTimeout = CONFIG.REQUEST_TIMEOUT_MS + 30_000;

server.on("clientError", (_error, socket) => {
  if (socket.writable) socket.end("HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n");
});

let shuttingDown = false;
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`Received ${signal}; closing Aster.`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 10_000).unref();
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));

server.listen(CONFIG.APP_PORT, CONFIG.APP_HOST, () => {
  console.log(`Aster is listening on port ${CONFIG.APP_PORT}`);
  console.log(`Model routes available: ${MODEL_CATALOG.length}`);
  console.log(`Web tools: ${CONFIG.ENABLE_WEB_TOOLS ? "enabled" : "disabled"}`);
  console.log(`Todo tool: ${CONFIG.ENABLE_TODO_TOOL ? "enabled" : "disabled"}`);
});
